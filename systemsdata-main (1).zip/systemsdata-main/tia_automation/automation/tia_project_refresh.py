from tia_automation import Siemens_Automator
import sys
import os 

if __name__ == '__main__':
    
    if len(sys.argv) >= 3:
        tia_path = sys.argv[1]
        project_path = sys.argv[2]
        
        if not (os.path.exists(tia_path) and os.path.exists(project_path)):
            sys.exit("File path does not exist")
        
        siemens = Siemens_Automator()
        if len(sys.argv) >= 4:
            artefact_path = sys.argv[3]
            siemens.tia_refresh_project(tia_path, project_path, artefact_path=artefact_path)
        elif len(sys.argv) >= 5:
            timeout = int(sys.argv[4])
            siemens.tia_refresh_project(tia_path, project_path, artefact_path=artefact_path, refresh_timeout=timeout)
        else:
            siemens.tia_refresh_project(tia_path, project_path)
        sys.exit(0)
    else:
        sys.exit("Insufficient arguments specified")