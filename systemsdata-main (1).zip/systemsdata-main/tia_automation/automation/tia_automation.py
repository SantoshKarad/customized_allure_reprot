from dematic.hmi.gui_automation import Window_GUI, Finder, logger
from image_db import ImageDatabase as db
from dematic.plcsim.api.manager import PlcSimManager
from PIL import Image, ImageFont, ImageDraw
import keyboard
import time
import sys
import os  
import cv2
import numpy as np

TIA_PATH = r'C:\Program Files\Siemens\Automation\Portal V17\Bin\Siemens.Automation.Portal.exe'
PROJECT_PATH = r'C:\Users\ElKamaZ\Documents\Automation\Sessions\Systems_LS_1\Systems_LS_1.als17'
PLC_SIM_PATH = r'C:\Program Files (x86)\SIEMENS\Automation\PLCSIMADV\bin\Siemens.Simatic.PlcSim.Advanced.UserInterface.exe'
PASS = 'Dematic17'

def create_blank(width, height, rgb_color=(0, 0, 0)):
    """Create new image(numpy array) filled with certain color in RGB"""
    # Create black blank image
    image = np.zeros((height, width, 3), np.uint8)

    # Since OpenCV uses BGR, convert the color first
    color = tuple(reversed(rgb_color))
    # Fill image with color
    image[:] = color

    return image

def place_text(text, base_img):

    org = (0, 0)
    color = (0, 0, 0)
    fontpath = "C:\Windows\Fonts\siemens_tia_portal_basic_regular.ttf"   
    
    font = ImageFont.truetype(fontpath, 12)
    img_pil = Image.fromarray(base_img)
    draw = ImageDraw.Draw(img_pil)
    draw.text(org,  text, font=font, fill = color)
    img = np.array(img_pil)
    
    return img
    
def generate_ip_image(text, width, height, rgb_color=(0, 0, 0)):
 
    background = create_blank(width, height, rgb_color)
    ip_img = place_text(text, background)
    cv2.imwrite(text + ".png", ip_img)

class Siemens_Automator():
    
    def sim_load_plc_instance(self, plc_sim, instance_name, ip_address=None, subnet_mask=None):
        plc_sim.select(db.SIM_TOGGLE, critical=False)
        plc_sim.select(db.SIM_DROPDOWN, critical=False)
        plc_sim.select(db.SIM_INSTANCE_NAME, mask=db.SIM_INSTANCE_NAME_MASK)
        keyboard.press_and_release('ctrl + a')
        keyboard.write(instance_name)
        if (ip_address is not None) and (subnet_mask is not None):
            plc_sim.select(db.SIM_IP_ADDRESS, mask=db.SIM_IP_ADDRESS_MASK)
            keyboard.press_and_release('ctrl + a')
            keyboard.write(ip_address)
            plc_sim.select(db.SIM_SUBNET, mask=db.SIM_SUBNET_MASK)
            keyboard.press_and_release('ctrl + a')
            keyboard.write(subnet_mask)
            
        time.sleep(1)
        plc_sim.select(db.SIM_START)
        
    def tia_download_plc_instance(self, ip_address, tia_path, project_path, artefact_path=None):
        portal = Window_GUI(tia_path, project_path, startup_delay=30, save_path=artefact_path)
        
        portal.set_post_click_wait(1)
        portal.set_max_search_time(30)
        portal.set_min_confidence(0.99)
        
        portal.select(db.OK, critical=False, min_confidence=0.95, max_search_time=10, wait_time=30, double_click=True)

        portal.maximise()
        portal.select(db.PROJECT_VIEW)
        
        logger.info('[' + __class__.__name__+ '] ' + 'Opening TIA extended load device dialogue')
        portal.select(db.SYSTEMS_CPU, max_search_time=30)
        portal.select(db.ONLINE)
        portal.select(db.EXTENDED_DOWNLOAD_OPTION)
        portal.select(db.TRUST_SOURCE, critical=False, max_search_time=10)
        
        logger.info('[' + __class__.__name__+ '] ' + 'Entering search specifications')
        portal.select(db.TYPE_PG_PC, mask=db.TYPE_PG_PC_MASK, wait_time=1)
        portal.select(db.PN_IE)
        portal.select(db.SEARCH_DEVICES_POPUP)
        portal.select(db.PG_PC, mask=db.PG_PC_MASK, wait_time=1)
        portal.select(db.ADAPTER)
        portal.select(db.SEARCH_DEVICES_POPUP)
        logger.info('[' + __class__.__name__+ '] ' + 'Finding compatible PLC instances')
        portal.select(db.START_SEARCH)
        portal.select(db.SEARCH_DEVICES_POPUP, wait_time=10)
        portal.select(db.DEVICE_TYPE)
        portal.select(db.SEARCH_DEVICES_POPUP, wait_time=1)
        
        logger.info('[' + __class__.__name__+ '] ' + 'Starting PLC search for desired instance IP')
        generate_ip_image(ip_address, 110, 15, (225,225,225))
        time.sleep(5)
        logger.info('[' + __class__.__name__+ '] ' + 'Selecting desired PLC instance')
        portal.select(ip_address + ".png", min_confidence=0.9)
        os.remove(ip_address + ".png")
        
        logger.info('[' + __class__.__name__+ '] ' + 'Opening TIA device load dialogue')
        portal.select(db.LOAD_2)
        
        logger.info('[' + __class__.__name__+ '] ' + 'Checking for optional dialogues')
        portal.select(db.TRUST_SOURCE, critical=False)
        portal.select(db.CONTINUE_WITHOUT_SYNCHRONIZATION, critical=False)
        
        # Getting passed safety information
        logger.info('[' + __class__.__name__+ '] ' + 'Filling required data fields for loading')
        
        portal.select(db.NO_ACTION, critical=False, max_search_time=10)
        portal.select(db.REINITIALISE, critical=False, max_search_time=5)
        portal.select(db.STOP_ALL, critical=False, max_search_time=5)
        
        portal.select(db.NO_ACTION, critical=False, max_search_time=10)
        portal.select(db.REINITIALISE, critical=False, max_search_time=5)
        portal.select(db.STOP_ALL, critical=False, max_search_time=5)
        
        portal.select(db.LOAD_SYSTEMS)
        portal.scroll(db.LOAD_SYSTEMS, distance=-1)
        
        if portal.exists(db.ENTER_PASSWORD):
            portal.select(db.ENTER_PASSWORD, critical=False)
            keyboard.press_and_release('ctrl + a')
            keyboard.write(PASS)
            keyboard.press_and_release('enter')
            
        portal.select(db.LOAD_1)
        start_time = time.time()
        
        logger.info('[' + __class__.__name__+ '] ' + 'Loading PLC instance')
        portal.select(db.FINISH, max_search_time=200)
        end_time=time.time()
        
        logger.info('[' + __class__.__name__+ '] ' + 'Load complete')
        logger.info('[' + __class__.__name__+ '] ' + ('Time taken: %.2fs' % (end_time-start_time)))
        logger.info('[' + __class__.__name__+ '] ' + 'Closing TIA portal')
        portal.close()
        time.sleep(5)
        
    def tia_refresh_project(self, tia_path, project_path, artefact_path=None, refresh_timeout=2400,  max_retries=3):
                
        N_retries = 0
        portal = Window_GUI(tia_path, project_path, startup_delay=30, save_path=artefact_path)
        portal.save_sequence = True
        portal.set_post_click_wait(1)
        portal.set_max_search_time(60)
        portal.set_min_confidence(0.99)
        
        portal.select(db.OK, critical=False, min_confidence=0.95, max_search_time=10, wait_time=30)
        portal.maximise()
        portal.select(db.PROJECT_VIEW)
            
        portal.select(db.REFRESH)
        
        start_time = time.time()
        while N_retries < max_retries:
            logger.info('[' + __class__.__name__+ '] ' + 'Starting refresh')
            portal.select(db.START_REFRESH)
            logger.info('[' + __class__.__name__+ '] ' + 'Waiting for TIA dialogue')
            res = portal.find_first([{'source': db.SERVER_ACCESS_WARNING, 'mask': None, 'min_confidence': 0.99}, {'source': db.CONNECTION_WARNING, 'mask': None, 'min_confidence': 0.99}, {'source': db.SUCCESSFUL_UPDATE_DIALOG, 'mask': None, 'min_confidence': 0.99}, {'source': db.SUCCESSFUL_REFRESH_DIALOG, 'mask': None, 'min_confidence': 0.99}], max_search_time=refresh_timeout)
            if (res != None and ((res.get('source') == db.SERVER_ACCESS_WARNING) or (res.get('source') == db.CONNECTION_WARNING))):
                logger.info('[' + __class__.__name__+ '] ' + 'Failure dialogue appeared')
                N_retries += 1
                portal.select(db.OK2, wait_time=1)
                if N_retries < max_retries:
                    logger.info('[' + __class__.__name__+ '] ' + 'Resolving and repeating refresh operation')
            else:
                break
        end_time = time.time()
        
        if res == None:
            portal.close()
            raise Exception('Refresh timed out')
        
        if N_retries >= max_retries:
            portal.close()
            raise Exception('Exceeded maximum retries')
        
        logger.info('[' + __class__.__name__+ '] ' + 'Refresh complete')
        logger.info('[' + __class__.__name__+ '] ' + ('Time taken: %.2fs' % (end_time-start_time)))
        portal.select(db.OK2, wait_time=1)
        portal.select(db.OK2, critical=False, max_search_time=5)
        
        logger.info('[' + __class__.__name__+ '] ' + 'Closing TIA portal')
        portal.close()
        time.sleep(5)
        
if __name__ == '__main__':
    
    if len(sys.argv) > 3:
        ip_address = sys.argv[1]
        tia_path = sys.argv[2]
        project_path = sys.argv[3]
        
        if not (os.path.exists(tia_path) and os.path.exists(project_path)):
            sys.exit("File path does not exist")
        
        siemens = Siemens_Automator()
        if len(sys.argv) >= 5:
            artefact_path = sys.argv[4]
            siemens.tia_download_plc_instance(ip_address, tia_path, project_path, artefact_path=artefact_path)
        else:
            siemens.tia_download_plc_instance(ip_address, tia_path, project_path)
        sys.exit(0)
    else:
        sys.exit("Insufficient arguments specified")
    
    '''
    plc_sim = Window_GUI(PLC_SIM_PATH, position="top_left")
    
    #Load new instances
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_1, IP_ADDRESS_1, SUBNET_MASK)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_2, IP_ADDRESS_2, SUBNET_MASK)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_3, IP_ADDRESS_3, SUBNET_MASK)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_4, IP_ADDRESS_4, SUBNET_MASK)
    
    #Load existing instances
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_1)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_2)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_3)
    sim_load_plc_instance(plc_sim, INSTANCE_NAME_4)
    '''