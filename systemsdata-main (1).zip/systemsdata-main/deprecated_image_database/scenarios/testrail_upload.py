# Zane El-Kamand
# 5/7/2022

from testrail import *
import pandas as pd 
import os

DIR = os.path.dirname(__file__)
FILE_PATH = os.path.join(DIR, 'HMI_GUI_Control_Scenarios_Testrail.xlsx')
API_INFO_PATH = os.path.join(DIR, 'connection.txt')

# Maximum number of steps in the excel
MAX_STEPS = 10
    
ADDRESS = 'https://testrail.dematic.com/'
    
# Connect to testrail server
def connect():

    with open(API_INFO_PATH) as f:
        user = f.readline()
        password = f.readline()
    
    client = APIClient(ADDRESS)
    client.user = user.strip()
    client.password = password.strip()
    return client

# Retrieve excel spreadsheet
def getExcel():
    df = pd.read_excel(FILE_PATH)
    return df

# Read excel fields into appropriate parameter fields
def extractExcelInfo(client, df):
    
    STEP_KEYPHRASE = "Scenario Step "
    RESULT_KEYPHRASE = "Expected Result "
    export_df = pd.DataFrame()
    failed_upload = False
    
    for _ , row in df.iterrows():
        # Iteration variable initialisation
        scenario_step = 1
        step_column_name = STEP_KEYPHRASE + str(scenario_step)
        result_column_name = RESULT_KEYPHRASE + str(scenario_step)
        
        # Form step array of dictionaries corresponding to individual steps
        steps = []
        while(scenario_step <= MAX_STEPS and pd.notnull(row[step_column_name])):
            steps.append(
            {
                "content" : row[step_column_name],
                "expected" : row[result_column_name]
            }
            )
            scenario_step += 1
            step_column_name = STEP_KEYPHRASE + str(scenario_step)
            result_column_name = RESULT_KEYPHRASE + str(scenario_step)
        
        # Populate testrail parameter fields
        info = {
        "title" : row['Title'],
        "custom_preconds" : row['Preconditions'],
        "custom_steps_separated" : steps
        }
        
        # Get image path for final expected result
        image_path = row['Image Path']
        
        # Upload to testrail
        try:
            if(pd.isnull(row['Case ID']) and failed_upload == False):
                case_id = addCase(client, info)
                attachment_id = addAttachment(client, case_id, image_path, steps)
            else:
                case_id = row['Case ID']
                attachment_id = row['Attachment ID']
                #updateCase(client, case_id, info)
        except:
            failed_upload = True
            case_id = ""
            attachment_id = ""
        
        # Prepare dataframe for export to excel
        export_row = row.to_frame().T
        export_row['Case ID'] = case_id
        export_row['Attachment ID'] = attachment_id
        export_df = pd.concat([export_df, export_row])
     
    # Form excel with CASE ID documented
    export_df.to_excel(FILE_PATH, index = False)

def updateCase(client, case_id, case_info):
    
    # Upload initial test case
    case_param = 'update_case/%i' % case_id
    case = client.send_post(case_param, case_info)
    
# Handle communications with testrail
def addCase(client, case_info):

    # Section Number (Manually obtained through 'get_case')
    HMI_GUI_SECTION_ID = 341749
    
    # Upload initial test case
    case_param = 'add_case/%i' % HMI_GUI_SECTION_ID
    case = client.send_post(case_param, case_info)
    case_id = case.get('id')
    
    return case_id
    
def addAttachment(client, case_id, image_path, steps):

    # Add attachment to test case if
    # image path is valid
    attachment_id = ""
    new_steps = steps
    
    if(os.path.exists(image_path)):
    
        attachment_param = 'add_attachment_to_case/%i' % case_id
        attachment = client.send_post(attachment_param, image_path)
        attachment_id = attachment.get('attachment_id')
       
        # Prepare POST inputs based on known image reference syntax
        # and ATTACHMENT ID
        update_param = 'update_case/%i' % case_id
        image_reference = '![](index.php?/attachments/get/%s)' % attachment_id
        # Update test case to place image into final expected result field
        # and push to server
        new_expected = {"expected" : image_reference}
        new_steps[-1].update(new_expected)
        update_info = {
            "custom_steps_separated" : new_steps
        } 
        client.send_post(update_param, update_info) 
    
    return attachment_id

if __name__ == '__main__':
    client = connect()
    df = getExcel()
    
    # Prevent accidental uploads or duplications
    response = input('Enter \'ok\' to confirm you wish to push changes to testrail:\n')
    if(response == 'ok'):
        extractExcelInfo(client, df)
      
    #print(client.send_get('get_case/%i' % 3016657))