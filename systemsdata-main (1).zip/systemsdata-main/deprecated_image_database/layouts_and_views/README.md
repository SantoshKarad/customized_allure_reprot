# Layout and Views

## Description
Image database of screenshots harvested from the HMI, to be used for future testing of the HMI. This folder is limited to those screenshots pertaining to the layouts and views of the HMI. 

## Naming Convention

The general structure of the file names:

- For conveyors:
	- As a general rule, '[image_file_name]_1' is for the conveyor view with ports represented in ID form. '[image_file_name]_2' is for conveyor view with ports in NUMBERED form.
	- *hmi_[conveyor_type]_standard* represents loading a conveyor detail screen assuming no TU present, no faults present, auto mode.
	- *hmi_[conveyor_type]_manual* represents loading a conveyor detail screen and activating manual mode.
	- *hmi_[conveyor_type]_manual_service_mode* represents loading a conveyor detail screen and activating service mode.
	- *hmi_[conveyor_type]_manual_bypass* represents loading a conveyor detail screen and activating photoeye bypass.
	- *hmi_[conveyor_type]_manual_add_TU* represents loading a conveyor detail screen and adding a TU.
	- *hmi_[conveyor_type]_manual_add_TU_Data* represents loading a conveyor detail screen and adding TU Data with TU already present.
	- *hmi_[conveyor_type]_manual_link* represents loading a conveyor detail screen and selecting all possible links for connected jogging.
	- **NOTE:** Some conveyors may have additional images that do not fall under the naming above.

Other screens do not have as formulaic naming as for the conveyors, however they still each follow some convention.

