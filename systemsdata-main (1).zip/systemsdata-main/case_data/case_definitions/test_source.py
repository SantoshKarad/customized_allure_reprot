# Author: Zane El-Kamand
# Date: 29/9/22

from dematic.hmi.gui_automation import Region, Point, ImageNotFoundError, _get_screen_region
from image_db import ImageDatabase as db
import time
import os 
import cv2
from datetime import datetime
        
class CommonPathwaysAndConfigurations:
    def __init__(self, hmi, plc):
        self.hmi = hmi
        self.plc = plc
        self.scrollbox_number_region = Region(393,279,33,20)
        self.scrollbox_max_number_region = Region(433,280,29,17)
        self.elevator_current_position_region = Region(119,349,110,25)
        self.elevator_target_position_region = Region(119,379,110,25)
        self.elevator_current_level_region = Region(80,349,35,25)
        self.elevator_target_level_region = Region(80,379,35,25)
        
        self.tcar_current_position_region = Region(118,356,110,25)
        self.tcar_target_position_region = Region(118,386,110,25)
        self.tcar_current_lane_region = Region(80,356,35,25)
        self.tcar_target_lane_region = Region(80,386,35,25)
        
        self.right_controls_region = Region(613,145,62,218)
        self.left_controls_region = Region(348,145,62,218)
        
        self.tu_id_region = Region(103,338,165,25)
        self.tu_current_loc_region = Region(103,362,165,25)
        
        self.tu_data_field_region = Region(574,288,80,30)
        self.tu_data_field_click_point = Point(630,300)
        self.tu_data_checkbox_region = Region(0,170,324,31)
        
        self.train_all_photoeye_region = Region(2,294,650,55)
        self.train_single_photoeye_region = Region(2,350,650,55)
        
        self.lift_button_region = Region(677,76,120,400)
        
        self.banner_time_region = Region(648,6,63,18)
        self.banner_date_region = Region(653,24,90,24)
        
        self.conveyor_name_region = Region(163,80,244,45)
        self.scrollbox_content_region = Region(285,230,175,30)
        #self.read_conveyor_name_config = {'invert':False, 'psm_mode':10, 'scale_factor':4, 'numbers_only':False, 'convert_to_int':False, 'show_postprocessed':False, 'suppress_ocr_output':False}
         
        self.zone_overview_inspection_region = Region(200,193,20,20)
        self.conveyor_overview_inspection_region = Region(354,237,60,60)
        
        self.read_numbers_config = {'lang':'eng', 'psm_mode':7, 'scale_factor':2, 'numbers_only':True, 'convert_to_int':True, 'show_postprocessed':False, 'suppress_ocr_output':False}
        self.read_text_config = {'lang':'eng', 'psm_mode':7, 'scale_factor':2, 'show_postprocessed':True}
        
    def _report_exception(self, error_str):
        self.hmi.add_comment(error_str)
        raise Exception(error_str)
    
    def _throw_equality_comparison_error(self, a, b):
        error_str = 'Comparison error: %s != %s' % (str(a), str(b))
        self._report_exception(error_str)
       
    def _clean_conveyor(self):
        self.hmi.select(db.MANUAL_OFF, max_search_time=1, critical=False)            
        self.hmi.select(db.REMOVE_TU, max_search_time=1, critical=False)                
        self.hmi.select(db.DELETE_TU_DATA, max_search_time=1, critical=False)                
        self.hmi.select(db.MANUAL_ON, max_search_time=1, critical=False)
    
    def _navigate_via_scrollbox_to_conveyor(self, conveyor_name, post_click_wait=None, clean=True):
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK, override_debug=True)
        self.hmi.select(db.SCROLLBOX_OVERVIEW, is_dropdown=True)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK)
        self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
        self.hmi.verify_on_screen(db.VIRTUAL_KEYBOARD_LOWERCASE)
        self.hmi.virtual_keyboard_write(conveyor_name)
        self.hmi.select(db.LOAD_SELECTION, wait_time=post_click_wait)
        
        if clean:
            self._clean_conveyor()
        
    def _navigate_to_scrollbox_overview(self):
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK)
        self.hmi.select(db.SCROLLBOX_OVERVIEW, is_dropdown=True)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK)
        
    def _navigate_to_zone_overview(self):
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.select(db.LAYOUT_OVERVIEW)
        self.hmi.select(db.HOMESCREEN)
    
    def _navigate_to_conveyor_overview(self):
        self._navigate_to_zone_overview()
        self.hmi.select(db.TURNTABLES_ZONE)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_MAIN)
        
    def _navigate_to_scanner(self):
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.select(db.SWITCH_TO_SCANNER_SCREEN)
        
    def _navigate_to_pncg(self):
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS)
        self.hmi.select(db.SLIDE_IN_MENU_DIAGNOSTICS)
        self.hmi.verify_on_screen(db.DIAGNOSTICS_SCREEN_STANDARD)
        self.hmi.select(db.SWITCH_TO_PNCG_SCREEN)
        self.hmi.verify_on_screen(db.DIAGNOSTICS_PNCG_UNSELECTED, mask=db.DIAGNOSTICS_PNCG_UNSELECTED_MASK)
        
    def _navigate_to_ecc(self):
        self._navigate_to_pncg()
        self.hmi.select(db.LOAD_SELECTION)
        self.hmi.verify_on_screen(db.DIAGNOSTICS_PNCG_SELECTED, mask=db.DIAGNOSTICS_PNCG_SELECTED_MASK)
        self.hmi.select(db.SWITCH_TO_ECC_SCREEN)
        
    def _navigate_to_virtual_keyboard(self):
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK, override_debug=True)
        self.hmi.select(db.SCROLLBOX_OVERVIEW, is_dropdown=True)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK)
        self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
        self.hmi.verify_on_screen(db.VIRTUAL_KEYBOARD_LOWERCASE)
        
    def _navigate_to_virtual_numpad(self):
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_operation('num')

class LayoutSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def C3017957(self):
        '''HMI - Alarms - Default view'''
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS)
        self.hmi.select(db.SLIDE_IN_MENU_ALARMS)
        self.hmi.verify_on_screen(db.ALARM_SCREEN_STANDARD, mask=db.ALARM_SCREEN_STANDARD_MASK, critical=True)
        
    def C3017989(self):
        '''HMI - Elevator - Default view'''
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self.hmi.verify_on_screen(db.ELEVATOR_SCREEN_DEFAULT, mask=db.ELEVATOR_SCREEN_DEFAULT_MASK, critical=True)
        
    def C3017988(self):
        '''HMI - TCar - Default view'''
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self.hmi.verify_on_screen(db.TCAR_SCREEN_DEFAULT, mask=db.TCAR_SCREEN_DEFAULT_MASK, critical=True)
        
    def C3017973(self):
        '''HMI - ConveyorZoneOverview - Default view'''
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.select(db.LAYOUT_OVERVIEW)
        self.hmi.select(db.HOMESCREEN)
        
    def C3017974(self):
        '''HMI - ConveyorOverview - Default view'''
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.select(db.LAYOUT_OVERVIEW)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.select(db.ELEVATOR_LOOP)
        
    def C3017969(self):
        '''HMI - Profinet - Default view'''
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS)
        self.hmi.select(db.SLIDE_IN_MENU_DIAGNOSTICS)
        self.hmi.verify_on_screen(db.DIAGNOSTICS_SCREEN_STANDARD)
        self.hmi.select(db.SWITCH_TO_DIAGNOSTICS_SCREEN)
        self.hmi.verify_on_screen(db.PROFINET_STANDARD, mask=db.PROFINET_STANDARD_MASK, critical=True)
            
    def C3017944(self):
        '''HMI - ConveyorHelp - Indicators tab display'''
        
        # Double clicking
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB, critical=True)
        
    def C3017945(self):
        '''HMI - ConveyorHelp - First navigation tab display'''
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB)
        self.hmi.select(db.HELP_SCREEN_NAVIGATION_TAB_BUTTON_1)
        self.hmi.verify_on_screen(db.HELP_SCREEN_NAVIGATION_TAB_1, critical=True)

        '''
        Steps:
         1. Select '?' from top banner.
         2. Select 'Navigation 1' tab.

        Results:
         1. Help screen loads into default view.
         2. ![](index.php?/attachments/get/24a4c980-b123-4e9e-82d8-978183d27c95)
        '''

    def C3017946(self):
        '''HMI - ConveyorHelp - Second navigation tab display'''
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB)
        self.hmi.select(db.HELP_SCREEN_NAVIGATION_TAB_BUTTON_2)
        self.hmi.verify_on_screen(db.HELP_SCREEN_NAVIGATION_TAB_2, critical=True)

        '''
        Steps:
         1. Select '?' from top banner.
         2. Select 'Navigation 2' tab.

        Results:
         1. Help screen loads into default view.
         2. ![](index.php?/attachments/get/d5c40cdf-6cab-4ea1-a49b-4ac0e7ee163b)
        '''

    def C3017947(self):
        '''HMI - ConveyorHelp - First controls tab display'''
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB)
        self.hmi.select(db.HELP_SCREEN_CONTROLS_TAB_BUTTON_1)
        self.hmi.verify_on_screen(db.HELP_SCREEN_CONTROLS_TAB_1, critical=True)

        '''
        Steps:
         1. Select '?' from top banner.
         2. Select 'Controls 1' tab.

        Results:
         1. Help screen loads into default view.
         2. ![](index.php?/attachments/get/fc3a1aa0-e8fd-4477-9c9f-103fcb83e6b0)
        '''

    def C3017948(self):
        '''HMI - ConveyorHelp - Second controls tab display'''
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB)
        self.hmi.select(db.HELP_SCREEN_CONTROLS_TAB_BUTTON_2)
        self.hmi.verify_on_screen(db.HELP_SCREEN_CONTROLS_TAB_2, critical=True)

        '''
        Steps:
         1. Select '?' from top banner.
         2. Select 'Controls 2' tab.

        Results:
         1. Help screen loads into default view.
         2. ![](index.php?/attachments/get/095000c0-5199-4d3f-ba13-54ca41611a4c)
        '''
        
    def C3151941(self):
        '''HMI - ConveyorHelp - Third controls tab display'''
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        self.hmi.select(db.SWITCH_TO_HELP_SCREEN)
        
        self.hmi.verify_on_screen(db.HELP_SCREEN_INDICATORS_TAB)
        self.hmi.select(db.HELP_SCREEN_CONTROLS_TAB_BUTTON_3)
        self.hmi.verify_on_screen(db.HELP_SCREEN_CONTROLS_TAB_3, critical=True)

        '''
        Steps:
         1. Select '?' from top banner.
         2. Select 'Controls 3' tab.

        Results:
         1. Help screen loads into default view.
         2. 
        '''

    def C3017949(self):
        '''HMI - ConveyorTUData - Transport tab display'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.TU_INFO_TRANSPORT_TAB_BUTTON)
        self.hmi.verify_on_screen(db.TU_INFO_SCREEN_TRANSPORT_TAB, mask=db.TU_INFO_SCREEN_TRANSPORT_TAB_MASK, critical=True)
        
    def C3017950(self):
        '''HMI - ConveyorTUData - Conveyor tab display'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.TU_INFO_CONVEYOR_TAB_BUTTON)
        self.hmi.verify_on_screen(db.TU_INFO_SCREEN_CONVEYOR_TAB, mask=db.TU_INFO_SCREEN_CONVEYOR_TAB_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100005' in selection field.
         4. Select checkmark button.
         5. Select TUData Icon.
         6. Select 'Conveyor' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU Data screen loads into default view.
         6. ![](index.php?/attachments/get/95d62236-db10-41c7-a18b-4cbdc2f93ed5)
        '''

    def C3017951(self):
        '''HMI - ConveyorTUData - AMCAP1 tab display'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.TU_INFO_AMCAP1_TAB_BUTTON)
        self.hmi.verify_on_screen(db.TU_INFO_SCREEN_AMCAP1_TAB, mask=db.TU_INFO_SCREEN_AMCAP1_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100005' in selection field.
         4. Select checkmark button.
         5. Select TUData Icon.
         6. Select 'AMCAP1' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU Data screen loads into default view.
         6. ![](index.php?/attachments/get/b7461297-08e4-4d8a-bf7e-6039944ac96a)
        '''

    def C3017952(self):
        '''HMI - ConveyorTUData - AMCAP2 tab display'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.TU_INFO_AMCAP2_TAB_BUTTON)
        self.hmi.verify_on_screen(db.TU_INFO_SCREEN_AMCAP2_TAB, mask=db.TU_INFO_SCREEN_AMCAP2_TAB_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100005' in selection field.
         4. Select checkmark button.
         5. Select TUData Icon.
         6. Select 'AMCAP2' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU Data screen loads into default view.
         6. ![](index.php?/attachments/get/d6f0b0b1-a2e6-4069-9d3a-30baf5f43393)
        '''
    
    def C3017953(self):
        '''HMI - Scanner - Data tab display'''
        self._navigate_to_scanner()
        self.hmi.select(db.SCANNER_DATA_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SCANNER_DATA_TAB, mask=db.SCANNER_DATA_TAB_MASK, critical=True)
        
        
    def C3017954(self):
        '''HMI - Scanner - Statistics tab display'''
        self._navigate_to_scanner()
        self.hmi.select(db.SCANNER_STATISTICS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SCANNER_STATISTICS_TAB, mask=db.SCANNER_STATISTICS_TAB_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100007' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Scanner' from menu.
         7. Select 'Statistics' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Scanner screen loads.
         7. ![](index.php?/attachments/get/3ff2322a-e8d4-43ca-bdaa-7e5e22a392a0)
        '''

    def C3017955(self):
        '''HMI - Scanner - History tab display'''
        self._navigate_to_scanner()
        self.hmi.select(db.SCANNER_HISTORY_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SCANNER_HISTORY_TAB, mask=db.SCANNER_HISTORY_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100007' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Scanner' from menu.
         7. Select 'History' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Scanner screen loads.
         7. ![](index.php?/attachments/get/edd12490-8efa-4e43-81ce-be8331df7ae9)
        '''

    def C3017956(self):
        '''HMI - Scanner - Faults tab display'''
        self._navigate_to_scanner()
        self.hmi.select(db.SCANNER_FAULTS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SCANNER_FAULTS_TAB, mask=db.SCANNER_FAULTS_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100007' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Scanner' from menu.
         7. Select 'Faults' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Scanner screen loads.
         7. ![](index.php?/attachments/get/eb8afbdb-ed06-4c4c-b812-39a20092f945)
        '''

    def C3017958(self):
        '''HMI - Alarms - Conveyor filter on'''
        self._navigate_via_scrollbox_to_conveyor('RT101190', post_click_wait=3)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.verify_on_screen(db.ALARM_SCREEN_FILTERED, mask=db.ALARM_SCREEN_UNFILTERED_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT101190' in selection field.
         4. Select checkmark button.
         5. Select hazard icon.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/4f406da7-0c0c-4765-b27e-0ace0ba6fde1)
        '''

    def C3017959(self):
        '''HMI - Alarms - Conveyor filter off'''
        self._navigate_via_scrollbox_to_conveyor('RT101190', post_click_wait=3)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.select(db.FILTER_FAULTS_BY_CONVEYOR_ON)
        self.hmi.verify_on_screen(db.ALARM_SCREEN_UNFILTERED, mask=db.ALARM_SCREEN_UNFILTERED_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT101190' in selection field.
         4. Select checkmark button.
         5. Select hazard icon.
         6. Toggle off filter button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor specific alarm screen loads.
         6. ![](index.php?/attachments/get/25702130-ff05-48eb-a259-b32b7c989ea6)
        '''

    def C3017960(self):
        '''HMI - PNCG - ECC - Status tab display'''
        self._navigate_to_ecc()
        self.hmi.select(db.ECC_STATUS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.ECC_STATUS_TAB, mask=db.ECC_STATUS_TAB_MASK, critical=True)
        
        
    def C3017961(self):
        '''HMI - PNCG - ECC - Warnings tab display'''
        self._navigate_to_ecc()
        self.hmi.select(db.ECC_WARNINGS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.ECC_WARNINGS_TAB, mask=db.ECC_WARNINGS_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Select 'Warnings' tab.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. ![](index.php?/attachments/get/e7be6ca0-7612-47b3-ac73-01141c65719d)
        '''

    def C3017962(self):
        '''HMI - PNCG - ECC - Faults tab display'''
        self._navigate_to_ecc()
        self.hmi.select(db.ECC_FAULTS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.ECC_FAULTS_TAB, mask=db.ECC_FAULTS_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Select 'Faults' tab.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. ![](index.php?/attachments/get/3c48096a-35e1-4f66-8c21-23270e27652b)
        '''

    def C3017963(self):
        '''HMI - PNCG - ECC - Login pop-up display'''
        self._navigate_to_ecc()
        self.hmi.select(db.OPEN_LOGIN_POPUP)
        self.hmi.verify_on_screen(db.LOGIN_POPUP, mask=db.LOGIN_POPUP_MASK, critical=True)
        self.hmi.select(db.LOGIN_POPUP_CLOSE)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Select person icon.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. ![](index.php?/attachments/get/598fe028-2f2c-48f3-adba-674cc5efce6d)
        '''

    def C3017964(self):
        '''HMI - PNCG - ECC - Post-login display'''
        self._navigate_to_ecc()
        self.hmi.select(db.OPEN_LOGIN_POPUP)
        self.hmi.select(db.USERNAME_BOX, mask=db.USERNAME_BOX_MASK)
        self.hmi.virtual_keyboard_write("Administrator")
        self.hmi.select(db.PASSWORD_BOX, mask=db.PASSWORD_BOX_MASK)
        self.hmi.virtual_keyboard_write("dematic")
        self.hmi.select(db.LOGIN_OK)
        self.hmi.verify_on_screen(db.ECC_POST_LOGIN_SCREEN, mask=db.ECC_POST_LOGIN_SCREEN_MASK, critical=True)
        
        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Select person icon.
         7. Enter correct login details into pop-up fields.
         8. Select 'OK'.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. Login pop-up appears on screen.
         7. Fields of login pop-up become populated with the entered data.
         8. ![](index.php?/attachments/get/8c20ab3f-e7bd-4d6f-9929-3f343d17112a)
        '''

    def C3017966(self):
        '''HMI - Pop-up - Keyboard input pop-up display'''
        self._navigate_to_scrollbox_overview()
        self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
        self.hmi.verify_on_screen(db.VIRTUAL_KEYBOARD_LOWERCASE, critical=True)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Select person icon.
         7. Select text field.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. Login pop-up appears on screen.
         7. ![](index.php?/attachments/get/a1820cfd-fb96-4b9a-bfe0-fc64af8d18bf)
        '''

    def C3017967(self):
        '''HMI - PNCG - Unselected view'''
        self._navigate_to_pncg()

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. ![](index.php?/attachments/get/084a6edd-e991-4f64-9e00-f1ef6a7e7e1d)
        '''

    def C3017968(self):
        '''HMI - PNCG - Selected view'''
        self._navigate_to_pncg()
        self.hmi.select(db.LOAD_SELECTION)
        self.hmi.verify_on_screen(db.DIAGNOSTICS_PNCG_SELECTED, mask=db.DIAGNOSTICS_PNCG_SELECTED_MASK, critical=True)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. ![](index.php?/attachments/get/8b018972-094f-4d97-9e0c-c7985522f921)
        '''

    def C3017970(self):
        '''HMI - WelcomeScreen - Default view'''
        self.hmi.verify_on_screen(db.WELCOME_SCREEN, mask=db.WELCOME_SCREEN_MASK, critical=True)

        '''
        Steps:
         1. Wait for HMI to connect to PLC.

        Results:
         1. ![](index.php?/attachments/get/9a2c26b0-8fe9-460d-b6fa-1db378b3e7a8)
        '''

    def C3017971(self):
        '''HMI - WelcomeScreen - Overview selection'''
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK, critical=True)

        '''
        Steps:
         1. Select overview selection dropdown.

        Results:
         1. ![](index.php?/attachments/get/d962908b-e825-46fd-8e80-fac67f1e96c7)
        '''

    def C3017972(self):
        '''HMI - ScrollboxOverview - Default view'''
        self._navigate_to_scrollbox_overview()

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. ![](index.php?/attachments/get/c73c5991-6cd0-4240-b644-bf74bd57baf4)
        '''

    def C3017975(self):
        '''HMI - Pop-up - Information pop-up display'''
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS)
        self.hmi.select(db.SLIDE_IN_MENU_ALARMS)
        self.hmi.verify_on_screen(db.ALARM_SCREEN_STANDARD, mask=db.ALARM_SCREEN_STANDARD_MASK)
        self.hmi.select(db.OPEN_ALARM_POPUP)
        self.hmi.select(db.ALARM_INFO_POPUP_CLOSE)

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Alarms' from menu.
         3. Select triple dot button.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Alarm screen loads.
         3. ![](index.php?/attachments/get/1a79eb21-5253-4115-b3a9-ca1ea6f97159)
        '''

    def C3017976(self):
        '''HMI - Pop-up - Shutdown confirmation pop-up display'''
        self.hmi.select(db.INITIATE_SHUTDOWN)
        self.hmi.verify_on_screen(db.SHUTDOWN_CONFIRMATION_POPUP, critical=True)
        self.hmi.select(db.SHUTDOWN_POPUP_CLOSE)

        '''
        Steps:
         1. Select power button from bottom of welcome screen.

        Results:
         1. ![](index.php?/attachments/get/98ba2f0c-417e-4d03-bf3f-e6e6353a53d5)
        '''

    def C3017977(self):
        '''HMI - Pop-up - Device list pop-up display'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100007' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/f4fbadfb-bbdc-49e2-acfd-00a3850d0ed5)
        '''

    def C3017978(self):
        '''HMI - Pop-up - Conveyor loading pop-up display'''
        self._navigate_via_scrollbox_to_conveyor('U000009', post_click_wait=0, clean=False)
        self.hmi.verify_on_screen(db.CONVEYOR_LOADING_POPUP, mask=db.CONVEYOR_LOADING_POPUP_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/c2faff5a-36da-4194-bcb3-8321234b238e)
        '''

    def C3017979(self):
        '''HMI - Pop-up - Conveyor selection pop-up display'''
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK)
        self.hmi.select(db.LAYOUT_OVERVIEW, is_dropdown=True)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.select(db.OPEN_CONVEYOR_SELECTION_POPUP)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_POPUP, mask=db.CONVEYOR_SELECTION_POPUP_MASK, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select dropdown icon in top-left of conveyor overview screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. ![](index.php?/attachments/get/a20b882b-b2f0-4700-89a7-7466d1b873a3)
        '''

    def C3017980(self):
        '''HMI - Banner - Slide in menu display'''
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS, critical=True)
        self.hmi.select(db.CLOSE_SLIDE_IN_MENU)
    
        '''
        Steps:
         1. Select slide menu button from top banner.

        Results:
         1. ![](index.php?/attachments/get/06b7905f-bfa2-4d36-b546-b5b3837e99c0)
         1. ![](index.php?/attachments/get/06b7905f-bfa2-4d36-b546-b5b3837e99c0)
        '''

    def C3017981(self):
        '''HMI - Banner - Language selection display'''
        self.hmi.select(db.LANGUAGE_DROPDOWN)
        self.hmi.verify_on_screen(db.LANGUAGE_DROPDOWN_OPTIONS, mask=db.LANGUAGE_DROPDOWN_OPTIONS_MASK, critical=True)
        self.hmi.select(db.LANGUAGE_DROPDOWN)

        '''
        Steps:
         1. Select language dropdown from top banner.

        Results:
         1. ![](index.php?/attachments/get/c5a0c2a0-cb62-4c3b-a575-c94aa5b771b3)
        '''

    def C3017990(self):
        '''HMI - SorterCommon - Default view'''
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_SORTER_SCREEN)
        
        if(self.hmi.exists(db.INHIBIT_COMMUNICATIONS_ON)):
            self.hmi.select(db.INHIBIT_COMMUNICATIONS_ON)
            
        self.hmi.verify_on_screen(db.SORTER_COMMON, mask=db.SORTER_COMMON_MASK, critical=True)
        
    def C3017991(self):
        '''HMI - SorterDivert - Status tab display: Default view'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_DIVERT_SCREEN)
        self.hmi.select(db.SORTER_STATUS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_DIVERT_STATUS_TAB, mask=db.SORTER_DIVERT_STATUS_TAB_MASK, critical=True)
        
    def C3017992(self):
        '''HMI - SorterDivert - Training tab display: Default view'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_DIVERT_SCREEN)
        self.hmi.select(db.SORTER_TRAINING_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_DIVERT_TRAINING_TAB, mask=db.SORTER_DIVERT_TRAINING_TAB_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. ![](index.php?/attachments/get/cbb4d288-3dbb-4642-9835-3b3f66291e97)
        '''
        
    def C3017993(self):
        '''HMI - SorterInduct - Status tab display''' 
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_INDUCT_SCREEN)
        self.hmi.select(db.SORTER_STATUS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_INDUCT_STATUS_TAB, mask=db.SORTER_INDUCT_STATUS_TAB_MASK, critical=True)
        
    def C3017994(self):
        '''HMI - SorterInduct - Control tab display: Default view'''
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_INDUCT_SCREEN)
        self.hmi.select(db.SORTER_CONTROL_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_INDUCT_CONTROL_TAB, mask=db.SORTER_INDUCT_CONTROL_TAB_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000005' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Induct' from menu.
         7. Select 'Control' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter induct screen loads.
         7. ![](index.php?/attachments/get/f818ee04-8063-4ad5-9aca-efa8f3e0d466)
        '''
        
    def C3017995(self):
        '''HMI - SorterPhotoeye - Status tab display'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.SORTER_STATUS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_STATUS_TAB, mask=db.SORTER_PHOTOEYE_STATUS_TAB_MASK, critical=True)
        
    def C3017996(self):
        '''HMI - SorterPhotoeye - Training tab display: Default view'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.SORTER_TRAINING_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_TRAINING_TAB, mask=db.SORTER_PHOTOEYE_TRAINING_TAB_MASK, critical=True)
    
    def C3225285(self):
        '''HMI - LightGrid - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('TR410100')
        self.hmi.select(db.HORIZONTAL_LIGHT_GRID)
        self.hmi.verify_on_screen(db.LIGHT_GRID_DEFAULT, mask=db.LIGHT_GRID_DEFAULT_MASK, critical=True)
        
    def C3225286(self):
        '''HMI - LightGrid - Training display: Default view'''
        self._navigate_via_scrollbox_to_conveyor('TR410100')
        self.hmi.select(db.HORIZONTAL_LIGHT_GRID)
        self.hmi.verify_on_screen(db.LIGHT_GRID_DEFAULT, mask=db.LIGHT_GRID_DEFAULT_MASK)
        self.hmi.select(db.LIGHT_GRID_TEACH)
        self.hmi.verify_on_screen(db.LIGHT_GRID_TEACH_POPUP, critical=True)
        self.hmi.select(db.ACCEPT)
        self.hmi.verify_on_screen(db.LIGHT_GRID_TEACHING_DEFAULT, mask=db.LIGHT_GRID_DEFAULT_MASK)
        
    def C3225701(self):
        '''HMI - BumpTurner - Default view'''
        self._navigate_via_scrollbox_to_conveyor('RT410070', clean=False) # Currently turning manual mode on for the conveyor during cleaning will turn the bump turner manual on
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_BUMP_TURNER)
        self.hmi.verify_on_screen(db.BUMP_TURNER_DEAFULT, mask=db.BUMP_TURNER_DEFAULT_MASK, critical=True)
        
    def C3225702(self):
        '''HMI - BumpTurner - Manual view: Default display'''
        self._navigate_via_scrollbox_to_conveyor('RT410070', clean=False) # Currently turning manual mode on for the conveyor during cleaning will turn the bump turner manual on
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_BUMP_TURNER)
        self.hmi.verify_on_screen(db.BUMP_TURNER_DEAFULT, mask=db.BUMP_TURNER_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.BUMP_TURNER_MANUAL_DEFAULT, mask=db.BUMP_TURNER_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
 
class ConveyorViews(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def C3017982(self):
        '''HMI - ExternalInterface - Type 1 default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('MR01_RT100845')
        self.hmi.verify_on_screen(db.MONORAIL_INTERFACE_DEFAULT, mask=db.MONORAIL_INTERFACE_DEFAULT_MASK, critical=True)
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'MR01_RT100845' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/fca21400-e20e-4a4a-b26c-9921ff9b0f44)
        '''

    def C3017984(self):
        '''HMI - ExternalInterface - Type 2 default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA200015_01Int')
        self.hmi.verify_on_screen(db.EXTERNAL_INTERFACE_DEFAULT, mask=db.EXTERNAL_INTERFACE_DEFAULT_MASK, critical=True)
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RA200015_01Int' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/0e472c9a-d6b1-49d5-8888-48f7069ff0c5)
        '''

    def C3017986(self):
        '''HMI - SrmConveyorInterface - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT200740SrmInt')
        self.hmi.verify_on_screen(db.SRM_INTERFACE_DEFAULT, mask=db.SRM_INTERFACE_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT200740SrmInt' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/ac5c07a0-310d-4765-ab66-0c64235b94b8)
        '''

    def C3017997(self):
        '''HMI - PalletTurntable - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX100200')
        self.hmi.verify_on_screen(db.TURNTABLE_DEFAULT, mask=db.TURNTABLE_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100200' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/39644089-aa15-4a86-b11a-0dabc2690e59)
        '''

    def C3017998(self):
        '''HMI - PalletTurntable - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX100200')
        self.hmi.verify_on_screen(db.TURNTABLE_DEFAULT, mask=db.TURNTABLE_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.TURNTABLE_MANUAL_DEFAULT, mask=db.TURNTABLE_MANUAL_DEFAULT_MASK, critical=True)
 
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100200' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/e9f45a6d-8ad1-4f5c-b207-209715ef6982)
        '''

    def C3017999(self):
        '''HMI - CaseAccum - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500005_02')
        self.hmi.verify_on_screen(db.ACCUMULATION_DEFAULT, mask=db.ACCUMULATION_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RA500005_02' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/dd03664a-7e93-4f3f-964d-6bfb9bb39b1e)
        '''

    def C3018000(self):
        '''HMI - CaseAccum - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500005_02')
        self.hmi.verify_on_screen(db.ACCUMULATION_DEFAULT, mask=db.ACCUMULATION_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.ACCUMULATION_MANUAL_DEFAULT, mask=db.ACCUMULATION_MANUAL_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RA500005_02' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/3c746e7e-b123-417e-a5fd-16b0c58ae824)
        '''

    def C3018001(self):
        '''HMI - CaseHighRateRat - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX200215')
        self.hmi.verify_on_screen(db.HIGH_RATE_RAT_DEFAULT, mask=db.HIGH_RATE_RAT_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX500025' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/06c0731d-7090-4368-9a86-753bbadcb7d8)
        '''

    def C3018002(self):
        '''HMI - CaseHighRateRat - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX200215')
        self.hmi.verify_on_screen(db.HIGH_RATE_RAT_DEFAULT, mask=db.HIGH_RATE_RAT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.HIGH_RATE_RAT_MANUAL_DEFAULT, mask=db.HIGH_RATE_RAT_MANUAL_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX500025' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/cb59178b-73ca-49f0-8cd6-10a2eb4ad904)
        '''

    def C3018003(self):
        '''HMI - CaseAccumSingle - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500050_02')
        self.hmi.verify_on_screen(db.ACCUMULATION_SINGLE_DEFAULT, mask=db.ACCUMULATION_SINGLE_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RA500050_02' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/289bcdd5-10a4-4fd1-a689-150f377ee1f0)
        '''

    def C3018004(self):
        '''HMI - CaseAccumSingle - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500050_02')
        self.hmi.verify_on_screen(db.ACCUMULATION_SINGLE_DEFAULT, mask=db.ACCUMULATION_SINGLE_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.ACCUMULATION_SINGLE_MANUAL_DEFAULT, mask=db.ACCUMULATION_SINGLE_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RA500050_02' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/47e72f75-e4f1-454d-89e9-72769ed54c83)
        '''

    def C3018005(self):
        '''HMI - ConveyorGravity - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100335')
        self.hmi.verify_on_screen(db.GRAVITY_CONVEYOR_DEFAULT, mask=db.GRAVITY_CONVEYOR_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100335' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/8b9c841f-c3d8-436e-8f0d-8245a492b452)
        '''

    def C3018006(self):
        '''HMI - CaseMerge - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT200810')
        self.hmi.verify_on_screen(db.MERGE_CONVEYOR_DEFAULT, mask=db.MERGE_CONVEYOR_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT200810' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/612bcc36-ed0f-477f-b65e-3308bd452c54)
        '''

    def C3018007(self):
        '''HMI - CaseMerge - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT200810')
        self.hmi.verify_on_screen(db.MERGE_CONVEYOR_DEFAULT, mask=db.MERGE_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.MERGE_CONVEYOR_MANUAL_DEFAULT, mask=db.MERGE_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT200810' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/992f09f6-7ed0-4158-9c73-76c9e61fc213)
        '''

    def C3018008(self):
        '''HMI - CaseRat - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX500025')
        self.hmi.verify_on_screen(db.RAT_CONVEYOR_DEFAULT, mask=db.RAT_CONVEYOR_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX500025' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/14908d2a-2e78-458a-8117-ec717017013e)
        '''

    def C3018009(self):
        '''HMI - CaseRat - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX500025')
        self.hmi.verify_on_screen(db.RAT_CONVEYOR_DEFAULT, mask=db.RAT_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.RAT_CONVEYOR_MANUAL_DEFAULT, mask=db.RAT_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX500025' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/21381318-ab7b-43da-a2bd-9b1ddb25d12a)
        '''

    def C3018010(self):
        '''HMI - CaseSwd - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX200175')
        self.hmi.verify_on_screen(db.SWD_CONVEYOR_DEFAULT, mask=db.SWD_CONVEYOR_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX200175' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/cc85aac8-ccb0-4e28-b2d8-57182f744af5)
        '''

    def C3018011(self):
        '''HMI - CaseSwd - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX200175')
        self.hmi.verify_on_screen(db.SWD_CONVEYOR_DEFAULT, mask=db.SWD_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.SWD_CONVEYOR_MANUAL_DEFAULT, mask=db.SWD_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX200175' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/e7a8bdb6-26cf-4541-aac5-78f810998b5c)
        '''

    def C3018012(self):
        '''HMI - CaseTransport - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT200010')
        self.hmi.verify_on_screen(db.TRANSPORT_CONVEYOR_DEFAULT, mask=db.TRANSPORT_CONVEYOR_DEFAULT_MASK, critical=True)
        

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT200010' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/7c95c306-627f-4d3c-85c5-6be76d31566e)
        '''

    def C3018013(self):
        '''HMI - CaseTransport - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT200010')
        self.hmi.verify_on_screen(db.TRANSPORT_CONVEYOR_DEFAULT, mask=db.TRANSPORT_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.TRANSPORT_CONVEYOR_MANUAL_DEFAULT, mask=db.TRANSPORT_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''[ self.hmi.select, kwargs, CASE_ID, HMI - CaseTransport - Manual view: Default display (Port ID representation)]
        
        }'''
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT200010' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/76a7569c-4f47-4bcb-8300-3addbdddc9ce)
        '''

    def C3018014(self):
        '''HMI - CaseTransportSingle - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('BT200070_01')
        self.hmi.verify_on_screen(db.TRANSPORT_SINGLE_CONVEYOR_DEFAULT, mask=db.TRANSPORT_SINGLE_CONVEYOR_DEFAULT_MASK, critical=True)
        
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'BT200070_01' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/4a486389-31db-415a-8ae3-15b7520e2e56)
        '''

    def C3018015(self):
        '''HMI - CaseTransportSingle - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('BT200070_01')
        self.hmi.verify_on_screen(db.TRANSPORT_SINGLE_CONVEYOR_DEFAULT, mask=db.TRANSPORT_SINGLE_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.TRANSPORT_SINGLE_CONVEYOR_MANUAL_DEFAULT, mask=db.TRANSPORT_SINGLE_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'BT200070_01' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/2b9a4d9e-a361-4fb6-b189-73be7248e9d3)
        '''

    def C3018016(self):
        '''HMI - PalletForklift - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100360')
        self.hmi.verify_on_screen(db.FORKLIFT_CONVEYOR_DEFAULT, mask=db.FORKLIFT_CONVEYOR_DEFAULT_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100360' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/d1a56b9a-2c0b-4a36-9dc7-bddc5c60368f)
        '''

    def C3018017(self):
        '''HMI - PalletForklift - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100360')
        self.hmi.verify_on_screen(db.FORKLIFT_CONVEYOR_DEFAULT, mask=db.FORKLIFT_CONVEYOR_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.FORKLIFT_CONVEYOR_MANUAL_DEFAULT, mask=db.FORKLIFT_CONVEYOR_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100360' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/7e05f57d-cc2c-4bc3-979b-459db158b536)
        '''

    def C3018018(self):
        '''HMI - PalletLiftTable - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX100510')
        self.hmi.verify_on_screen(db.LIFT_TABLE_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK, critical=True)
    
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100510' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/11bc138e-cea6-4f9a-a7e1-86cb604fda20)
        '''

    def C3018019(self):
        '''HMI - PalletLiftTable - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RX100510')
        self.hmi.verify_on_screen(db.LIFT_TABLE_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.LIFT_TABLE_MANUAL_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100510' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/337aad5d-76c9-4df5-a7ac-dcb406651c1c)
        '''

    def C3018020(self):
        '''HMI - PalletSlug - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100110')
        self.hmi.verify_on_screen(db.SLUG_DEFAULT, mask=db.SLUG_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100110' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/c2becea0-ebe5-48cf-8f28-8b4c242f4d61)
        '''
        
    def C3018021(self):
        '''HMI - PalletSlug - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100110')
        self.hmi.verify_on_screen(db.SLUG_DEFAULT, mask=db.SLUG_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.SLUG_MANUAL_DEFAULT, mask=db.SLUG_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100110' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/1c27a904-1000-42a3-8de1-d6b59b53f30d)
        '''
    
    def C3018022(self):
        '''HMI - PalletSlug - Default view: Second location tab display'''
        self._navigate_via_scrollbox_to_conveyor('RT100110')
        self.hmi.verify_on_screen(db.SLUG_DEFAULT, mask=db.SLUG_DEFAULT_MASK)
        self.hmi.select(db.SLUG_LOCATION_2)
        self.hmi.verify_on_screen(db.SLUG_LOCATION_2_DEFAULT, mask=db.SLUG_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RT100110' in selection field.
         4. Select checkmark button.
         5. Select location '2' tab.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/2fffa62a-15f4-4811-9ef4-ccb8d5309517)
        '''
    
    def C3018023(self):
        '''HMI - PalletStraight - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100010' in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/89731f93-a87f-4673-ba35-3c4fa5c7a675)
        '''

    def C3018024(self):
        '''HMI - PalletStraight - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_MANUAL_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100010' in selection field.
         4. Select checkmark button.
         5. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. ![](index.php?/attachments/get/ee89cfd3-84f8-4581-87da-ac13f5a08358)
        '''
    
    def C3155525(self):
        '''HMI - CaseAccumMaster - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500005_01')
        self.hmi.verify_on_screen(db.ACCUMULATION_MASTER_DEFAULT, mask=db.ACCUMULATION_MASTER_DEFAULT_MASK, critical=True)
        
    def C3155526(self):
        '''HMI - CaseAccumMaster - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RA500005_01')
        self.hmi.verify_on_screen(db.ACCUMULATION_MASTER_DEFAULT, mask=db.ACCUMULATION_MASTER_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.ACCUMULATION_MASTER_MANUAL_DEFAULT, mask=db.ACCUMULATION_MASTER_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
    def C3225281(self):
        '''HMI - MultiTuTransport - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT410090')
        self.hmi.verify_on_screen(db.MULTI_TU_TRANSPORT_DEFAULT, mask=db.MULTI_TU_TRANSPORT_DEFAULT_MASK, critical=True)
    
    def C3225282(self):
        '''HMI - MultiTuTransport - Manual view: Default display (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('RT410090')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.MULTI_TU_TRANSPORT_MANUAL_DEFAULT, mask=db.MULTI_TU_TRANSPORT_DEFAULT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
    def C3225283(self):
        '''HMI - Trayer - Default view (Port ID representation)'''
        self._navigate_via_scrollbox_to_conveyor('TR410100')
        self.hmi.verify_on_screen(db.TRAYER_DEFAULT, mask=db.TRAYER_DEFAULT_MASK, critical=True)
    
class InputSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def C3146370(self):
        '''HMI - Keyboard - Alphabetical entry keys'''
        self._navigate_to_virtual_keyboard()
        lowercase_alphabet = "abcdefghijklmnopqrstuvwxyz"
        uppercase_alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        for character in lowercase_alphabet:
            self.hmi.virtual_keyboard_write(character)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not character:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            
        for character in uppercase_alphabet:
            self.hmi.virtual_keyboard_write(character)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not character:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            
    def C3146371(self):
        '''HMI - Keyboard - Special character keys'''
        self._navigate_to_virtual_keyboard()
        special_characters = ".,/:\\;\'[]-=!@#$%^&*()_+{}\"|?<>"
        for character in special_characters:
            self.hmi.virtual_keyboard_write(character)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not character:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            
    def C3146372(self):
        '''HMI - Keyboard - Numerical entry keys'''
        self._navigate_to_virtual_keyboard()
        number_str = "0123456789"
        for number in number_str:
            self.hmi.virtual_keyboard_write(number)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not number:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            
    def C3146373(self):
        '''HMI - Numpad - Numerical entry keys'''
        self._navigate_to_virtual_numpad()
        number_str = "0123456789"
        for number in number_str:
            self.hmi.virtual_numpad_write(number)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not number:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            self.hmi.virtual_keyboard_operation('num')
            
    def C3146374(self):
        '''HMI - Numpad - Special character keys'''
        self._navigate_to_virtual_numpad()
        numpad_str = "-."
        for entry in numpad_str:
            self.hmi.virtual_numpad_write(entry)
            clipboard = self.hmi.read_clipboard()
            if clipboard is not entry:
                self._throw_equality_comparison_error(clipboard,character)
            self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
            self.hmi.virtual_keyboard_operation('num')
    
    def C3146375(self):
        '''HMI - Keyboard - Input greater than max string '''        
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc")
        self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
        self.hmi.virtual_keyboard_write("abcdefghijklmno")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "abc":
            self._throw_equality_comparison_error(clipboard,"abc")
            
    def C3146376(self):     
        '''HMI - Keyboard - Empty character entry'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc")
        self.hmi.select(db.INPUT_BOX, mask=db.INPUT_BOX_MASK)
        self.hmi.virtual_keyboard_operation("backspace")
        self.hmi.virtual_keyboard_operation("enter")
        self.hmi.verify_on_screen(db.KEYBOARD_EMPTY_ENTRY, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. ![](index.php?/attachments/get/681a71cc-a670-4105-b2b0-17a6cb470bb1)
        '''

    def C3016609(self):
        '''HMI - Numpad - Input manipulation through backspace operation'''        
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("backspace")
        self.hmi.virtual_numpad_operation("enter")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "12":
            self._throw_equality_comparison_error(clipboard,"12")
                
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.
         11. Press backspace button on numpad screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digit entered appears in top bar of display.
         11. Digit is removed from top bar display.
        '''

    def C3016610(self):
        '''HMI - Numpad - Popup close through window exit'''
        self._navigate_to_virtual_numpad()
        self.hmi.select(db.VIRTUAL_INPUT_EXIT)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.
         11. Press 'x' in top right of popup to close numpad screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digit entered appears in top bar of display.
         11. Numpad popup dissapears.      Digit entered does not appear in the input field of screen.
        '''

    def C3016611(self):
        '''HMI - Numpad - Popup close through escape button'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_operation("esc")
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.
         11. Press 'Esc' button to close numpad screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digit entered appears in top bar of display.
         11. Numpad popup dissapears.      Digit entered does not appear in the input field of screen.
        '''

    def C3016612(self):
        '''HMI - Numpad - Cursor positioning through home button'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("home")
        self.hmi.virtual_numpad_write("0")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "0123":
            self._throw_equality_comparison_error(clipboard,"0123")
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a double digit number into numpad.
         11. Press 'Home' button on screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digits entered appears in top bar of display.
         11. ![](index.php?/attachments/get/fe2e0d83-aafa-4ed0-9b83-e8fcb3cf89a4)
        '''

    def C3016613(self):
        '''HMI - Numpad - Cursor positioning through end button'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("home")
        self.hmi.virtual_numpad_operation("end")
        self.hmi.virtual_numpad_write("4")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "1234":
            self._throw_equality_comparison_error(clipboard,"1234")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a double digit number into numpad.
         11. Press 'End' button on screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digits entered appears in top bar of display.
         11. ![](index.php?/attachments/get/720ba455-aa90-4b25-8f1a-60167426dced)
        '''

    def C3016614(self):
        '''HMI - Numpad - Cursor positioning through left arrow button'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("left")
        self.hmi.virtual_numpad_write("0")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "1203":
            self._throw_equality_comparison_error(clipboard,"1203")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a double digit number into numpad.
         11. Press left arrow button on screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digits entered appears in top bar of display.
         11. Cursor in top bar shifts one position to the left.
        '''

    def C3016615(self):
        '''HMI - Numpad - Cursor positioning through right arrow button'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("home")
        self.hmi.virtual_numpad_operation("right")
        self.hmi.virtual_numpad_write("0")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "1023":
            self._throw_equality_comparison_error(clipboard,"1023")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a double digit number into numpad.
         11. Press right arrow button on screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digits entered appears in top bar of display.
         11. Cursor in top bar shifts one position to the right.
        '''

    def C3016616(self):
        '''HMI - Numpad - Cursor positioning through top bar'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.select(db.NUMPAD_INPUT_BAR_MIDDLE)
        self.hmi.virtual_numpad_write("0")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "1023":
            self._throw_equality_comparison_error(clipboard,"1023")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a double digit number into numpad.
         11. Press screen in position between two digits.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digits entered appears in top bar of display.
         11. ![](index.php?/attachments/get/e72dfbf7-46fa-49d0-b096-5d0585accf2b)
        '''

    def C3016617(self):
        '''HMI - Numpad - Input manipulation through insert operation'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("left")
        self.hmi.virtual_numpad_operation("ins")
        self.hmi.virtual_numpad_write("0")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "120":
            self._throw_equality_comparison_error(clipboard,"120")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.
         11. Move one digit left on numpad screen through the left arrow button.     Press 'Ins' button.     Enter a single digit number into numpad.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digit entered appears in top bar of display.
         11. Digit is replaced by newly entered digit.
        '''

    def C3016618(self):
        '''HMI - Numpad - Input manipulation through delete operation'''
        self._navigate_to_virtual_numpad()
        self.hmi.virtual_numpad_write("123", submit_after_entry=False)
        self.hmi.virtual_numpad_operation("left")
        self.hmi.virtual_numpad_operation("del")
        self.hmi.virtual_numpad_operation("enter")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "12":
            self._throw_equality_comparison_error(clipboard,"12")

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Training' tab.
         8. Select field edit button.
         9. Select highlighted field to enter data.
         10. Enter a single digit number into numpad.
         11. Move one digit left on numpad screen through the left arrow button.     Press 'Del' button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Edit button turns blue.     Training input field highlights.
         9. Numpad popup appears on screen.
         10. Digit entered appears in top bar of display.
         11. Digit is removed from top bar display.
        '''

    def C3016619(self):
        '''HMI - Keyboard - Lowercase keyboard'''
        self._navigate_to_virtual_keyboard()
        self.hmi.verify_on_screen(db.VIRTUAL_KEYBOARD_LOWERCASE, critical=True)

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. ![](index.php?/attachments/get/1cc40177-303d-4a1a-b599-da340fcfa64f)
        '''

    def C3016620(self):
        '''HMI - Keyboard - Uppercase keyboard'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_operation('caps')
        self.hmi.verify_on_screen(db.VIRTUAL_KEYBOARD_UPPERCASE, critical=True)

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Select either uppercase mode button on the keyboard.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen in lowercase view.
         4. ![](index.php?/attachments/get/f1a92e46-f6f7-4064-bff5-5927d0c29b14)
        '''

    def C3016623(self):
        '''HMI - Keyboard - Input manipulation thorugh backspace operation'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("backspace")
        self.hmi.virtual_keyboard_operation("enter")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "ab":
            self._throw_equality_comparison_error(clipboard,"ab")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press backspace button on keyboard.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Alphanumeric character is removed from top bar display.
        '''

    def C3016624(self):
        '''HMI - Keyboard - Popup close through window exit'''
        self._navigate_to_virtual_keyboard()
        self.hmi.select(db.VIRTUAL_INPUT_EXIT)
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK, critical=True)

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press 'x' in top right of popup to close keyboard screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Keyboard popup dissapears.      Alphanumeric character entered does not appear in the input field of screen.
        '''

    def C3016625(self):
        '''HMI - Keyboard - Popup close through escape button'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_operation("esc")
        self.hmi.verify_on_screen(db.CONVEYOR_SELECTION_STANDARD, mask=db.CONVEYOR_SELECTION_STANDARD_MASK, critical=True)

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press 'Esc' button to close keyboard screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Keyboard popup dissapears.      Alphanumeric character entered does not appear in the input field of screen.
        '''

    def C3016626(self):
        '''HMI - Keyboard - Cursor positioning through home button'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("home")
        self.hmi.virtual_keyboard_write("z")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "zabc":
            self._throw_equality_comparison_error(clipboard,"zabc")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press 'Home' button on screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. ![](index.php?/attachments/get/c7888d32-8790-404f-b074-5389b6a62dc1)
        '''

    def C3016627(self):
        '''HMI - Keyboard - Cursor positioning through end button'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("home")
        self.hmi.virtual_keyboard_operation("end")
        self.hmi.virtual_keyboard_write("d")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "abcd":
            self._throw_equality_comparison_error(clipboard,"abcd")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press 'End' button on screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. ![](index.php?/attachments/get/b28b9e06-a4e1-48d9-9999-e363e9d1b355)
        '''

    def C3016628(self):
        '''HMI - Keyboard - Cursor positioning through left arrow button'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("left")
        self.hmi.virtual_keyboard_write("d")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "abdc":
            self._throw_equality_comparison_error(clipboard,"abdc")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press left arrow button on screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Cursor in top bar shifts one position to the left.
        '''

    def C3016629(self):
        '''HMI - Keyboard - Cursor positioning through right arrow button'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("home")
        self.hmi.virtual_keyboard_operation("right")
        self.hmi.virtual_keyboard_write("d")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "adbc":
            self._throw_equality_comparison_error(clipboard,"adbc")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Press right arrow button on screen.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Cursor in top bar shifts one position to the right.
        '''

    def C3016630(self):
        '''HMI - Keyboard - Cursor positioning through top bar'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.select(db.KEYBOARD_INPUT_BAR_MIDDLE)
        self.hmi.virtual_keyboard_write("d")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "adbc":
            self._throw_equality_comparison_error(clipboard,"adbc")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a short alphanumeric string via keyboard.
         5. Press screen in position between two alphanumeric characters.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric string entered appears in top bar of display.
         5. ![](index.php?/attachments/get/b0606107-222b-4ae2-9779-40fea3c1867c)
        '''

    def C3016631(self):
        '''HMI - Keyboard - Input manipulation through insert operation'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("left")
        self.hmi.virtual_keyboard_operation("ins")
        self.hmi.virtual_keyboard_write("d")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "abd":
            self._throw_equality_comparison_error(clipboard,"abd")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Move one character left on keyboard screen through the left arrow button.     Press 'Ins' button.     Enter a single character into keyboard.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Alphanumeric character is replaced by newly entered alphanumeric character.
        '''

    def C3016632(self):
        '''HMI - Keyboard - Input manipulation through delete operation'''
        self._navigate_to_virtual_keyboard()
        self.hmi.virtual_keyboard_write("abc", submit_after_entry=False)
        self.hmi.virtual_keyboard_operation("left")
        self.hmi.virtual_keyboard_operation("del")
        self.hmi.virtual_keyboard_operation("enter")
        clipboard = self.hmi.read_clipboard()
        if clipboard != "ab":
            self._throw_equality_comparison_error(clipboard,"ab")

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Enter a single alphanumeric character via keyboard.
         5. Move one character left on keyboard screen through the left arrow button.     Press 'Del' button.

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Alphanumeric character entered appears in top bar of display.
         5. Alphanumeric character is removed from top bar display.
        '''

    def C3016633(self):
        '''HMI - Keyboard - Switch to numpad entry method'''
        self._navigate_to_virtual_numpad()
        self.hmi.verify_on_screen(db.NUMPAD_FROM_KEYBOARD, critical=True)

        '''
        Steps:
         1. Press to continue.
         2. Select dropdown icon in top-left of conveyor overview screen.
         3. Select input field for conveyor specification.
         4. Select 'Num' button

        Results:
         1. Conveyor overview screen loads.
         2. Conveyor selection pop-up loads.
         3. Keyboard popup appears on screen.
         4. Screen switches to numpad input screen.
        '''

class NavigationSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def _home_scrollbox(self):
        max_number = self.hmi.read_region(self.scrollbox_max_number_region, **self.read_numbers_config)
        initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        mid_number = int(max_number/2)
        residual = max_number-initial_number+1
        
        if(initial_number <= mid_number):
            tens = int(initial_number/10)
            ones = initial_number % 10
            self.hmi.repeat_operation(self.hmi.select, tens, source=db.DOWN_TEN_CONVEYORS)
            self.hmi.repeat_operation(self.hmi.select, ones, source=db.DOWN_ONE_CONVEYOR)
            
        elif(initial_number > mid_number):
            tens = int(residual/10)
            ones = (residual % 10)
            self.hmi.repeat_operation(self.hmi.select, tens, source=db.UP_TEN_CONVEYORS)
            self.hmi.repeat_operation(self.hmi.select, ones, source=db.UP_ONE_CONVEYOR)
        
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        if(final_number != 0):
            self._report_exception('Failed to home scrollbox')
    
    def C3016681(self):
        '''HMI - ConveyorOverview - Zone switch buttons (Left arrow)'''
        self._navigate_to_conveyor_overview()
        self.hmi.select(db.LEFT_ONE_SCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_LEFT, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select left arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Screen changes to show overview of a different control zone.
        '''

    def C3016682(self):
        '''HMI - ConveyorOverview - Zone switch buttons (Right arrow)'''
        self._navigate_to_conveyor_overview()
        self.hmi.select(db.RIGHT_ONE_SCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_RIGHT, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select right arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Screen changes to show overview of a different control zone.
        '''

    def C3016683(self):
        '''HMI - ConveyorOverview - Zone switch buttons (Up arrow)'''
        self._navigate_to_conveyor_overview()
        self.hmi.select(db.UP_ONE_SCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_UP, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select up arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Screen changes to show overview of a different control zone.
        '''

    def C3016684(self):
        '''HMI - ConveyorOverview - Zone switch buttons (Down arrow)'''
        self._navigate_to_conveyor_overview()
        self.hmi.select(db.DOWN_ONE_SCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_DOWN, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select down arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Screen changes to show overview of a different control zone.
        '''

    def C3016685(self):
        '''HMI - ConveyorOverview - Zone switch buttons (Return button)'''
        self._navigate_to_conveyor_overview()
        self.hmi.select(db.DOWN_ONE_SCREEN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_DOWN)
        self.hmi.select(db.RETURN)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_MAIN, critical=True)
        
        '''
        x=0
        succeses = 0
        self._navigate_to_scrollbox_overview()
        while x < 110:
            initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
            self.hmi.select(db.UP_ONE_CONVEYOR)
            
            succeses = succeses + (initial_number==str(x))
            x = x+1
            #print(initial_number)
        print(succeses/x * 100)
        pass
        '''
        
        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select up arrow button at bottom of screen.
         5. Select return arrow button at bottom-right of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Screen changes to show overview of a different control zone.
         5. Screen switches back to original conveyor overview.
        '''

    def C3016686(self):
        '''HMI - ScrollboxOverview - Jump up one conveyor'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        self.hmi.select(db.UP_ONE_CONVEYOR, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number-initial_number==1):
            self._throw_equality_comparison_error(final_number-initial_number, 1)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '0/[MAX]'
         4. Select the up arrow without a subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '0/[MAX].'
         4. Conveyor number below scrollbox increases by 1.
        '''

    def C3016687(self):
        '''HMI - ScrollboxOverview - Jump down one conveyor (Rotating numbers)'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        max_number = self.hmi.read_region(self.scrollbox_max_number_region, **self.read_numbers_config)
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number-max_number==0):
            self._throw_equality_comparison_error(final_number-max_number, 0)
    
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '0/[MAX]'
         4. Select the down arrow without a subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '0/[MAX].'
         4. Conveyor number below scrollbox changes to '[MAX]/[MAX].'
        '''

    def C3016688(self):
        '''HMI - ScrollboxOverview - Jump up ten conveyors'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        self.hmi.select(db.UP_TEN_CONVEYORS, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number-initial_number==10):
            self._throw_equality_comparison_error(final_number-initial_number, 10)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '0/[MAX]'
         4. Select the up arrow with the '10' subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '0/[MAX].'
         4. Conveyor number below scrollbox increases by 10.
        '''

    def C3016689(self):
        '''HMI - ScrollboxOverview - Jump down ten conveyors'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        max_number = self.hmi.read_region(self.scrollbox_max_number_region, **self.read_numbers_config)
        self.hmi.select(db.DOWN_TEN_CONVEYORS, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (max_number-final_number==9):
            self._throw_equality_comparison_error(max_number-final_number, 9)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '0/[MAX]'
         4. Select the down arrow with the '10' subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '0/[MAX].'
         4. Conveyor number below scrollbox changes to '[MAX-9]/[MAX].'
        '''

    def C3016690(self):
        '''HMI - ScrollboxOverview - Jump up one conveyor (Rotating numbers)'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        self.hmi.select(db.UP_ONE_CONVEYOR, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number==0):
            self._throw_equality_comparison_error(final_number, 0)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '[MAX]/[MAX]'
         4. Select the up arrow without a subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '[MAX]/[MAX].'
         4. Conveyor number below scrollbox changes to '0/[MAX].'
        '''

    def C3016691(self):
        '''HMI - ScrollboxOverview - Jump down one conveyor'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (initial_number-final_number==1):
            self._throw_equality_comparison_error(initial_number-final_number, 1)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '[MAX]/[MAX]'
         4. Select the down arrow without a subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '[MAX]/[MAX].'
         4. Conveyor number below scrollbox decreases by 1.
        '''

    def C3016692(self):
        '''HMI - ScrollboxOverview - Jump up ten conveyors (Rotating numbers)'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        self.hmi.select(db.UP_TEN_CONVEYORS, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number==9):
            self._throw_equality_comparison_error(final_number, 9)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '[MAX]/[MAX]'
         4. Select the up arrow with the '10' subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '[MAX]/[MAX].'
         4. Conveyor number below scrollbox changes to '9/[MAX].'
        '''

    def C3016693(self):
        '''HMI - ScrollboxOverview - Jump down ten conveyors'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        self.hmi.select(db.DOWN_ONE_CONVEYOR, wait_time=1)
        initial_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        self.hmi.select(db.DOWN_TEN_CONVEYORS, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (initial_number-final_number==10):
            self._throw_equality_comparison_error(initial_number-final_number, 10)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '[MAX]/[MAX]'
         4. Select the down arrow with the '10' subscript.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '[MAX]/[MAX].'
         4. Conveyor number below scrollbox decreases by 10.
        '''

    def C3016694(self):
        '''HMI - ScrollboxOverview - Reset button'''
        self._navigate_to_scrollbox_overview()
        self._home_scrollbox()
        self.hmi.select(db.UP_TEN_CONVEYORS, wait_time=1)
        self.hmi.select(db.RESET_SELECTION, wait_time=1)
        final_number = self.hmi.read_region(self.scrollbox_number_region, **self.read_numbers_config)
        
        if not (final_number==0):
            self._throw_equality_comparison_error(final_number, 0)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Set the conveyor number below scrollbox to '0/[MAX]'
         4. Select the up arrow with the '10' subscript.
         5. Select the reset button to the left of the scrollbox.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor number below scrollbox reads '0/[MAX].'
         4. Conveyor number below scrollbox increases by 10.
         5. Conveyor number below scrollbox resets to '0/[MAX].'
        '''

    def C3016696(self):
        '''HMI - WelcomeScreen - Dematic button shortcut'''
        self._navigate_to_scrollbox_overview()
        self.hmi.select(db.DEMATIC)
        self.hmi.verify_on_screen(db.WELCOME_SCREEN, mask=db.WELCOME_SCREEN_MASK, critical=True)
    
        '''
        Steps:
         1. Navigate to any screen that is not the welcome screen.
         2. Select 'Dematic' from the HMI top banner.

        Results:
         1. Selected HMI screen loads into view.
         2. Welcome screen loads back into view.
        '''

    def C3016697(self):
        '''HMI - AlarmScreen - Alarm list scroll functionality'''
        self.hmi.select(db.OPEN_SLIDE_IN_MENU)
        self.hmi.verify_on_screen(db.SLIDE_MENU_OPTIONS)
        self.hmi.select(db.SLIDE_IN_MENU_ALARMS)
        self.hmi.verify_on_screen(db.ALARM_SCREEN_STANDARD, mask=db.ALARM_SCREEN_STANDARD_MASK, critical=True)
        self.hmi.scroll(db.ALARM_SCREEN_STANDARD, mask=db.ALARM_SCREEN_STANDARD_MASK, distance=-100)
        
        self.hmi.warning = True
        self.hmi.add_comment('Not final version of test case, will be updated with more verifications')
    
        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Alarms' from menu.
         3. Scroll through the alarm list.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Alarm screen loads with large list of faults.
         3. Alarm list moves with scroll gesture on the HMI screen.
        '''

    def C3016699(self):
        '''HMI - Shutdown - Rejected HMI shutdown'''
        self.hmi.select(db.INITIATE_SHUTDOWN)
        self.hmi.verify_on_screen(db.SHUTDOWN_CONFIRMATION_POPUP)
        self.hmi.select(db.REJECT_SHUTDOWN)
        
        '''
        Steps:
         1. Select power button from bottom of welcome screen.
         2. Select 'X' button to reject shutdown.

        Results:
         1. Shutdown confirmation pop-up appears on screen.
         2. Shutdown pop-up disappears and screen returns to welcome screen.
        '''

    def C3016700(self):
        '''HMI - NoOverview - Navigation to conveyor screens without overview'''
        self.hmi.select(db.OVERVIEW_SELECTION_DROPDOWN)
        self.hmi.verify_on_screen(db.OVERVIEW_OPTIONS, mask=db.OVERVIEW_OPTIONS_MASK, override_debug=True)
        self.hmi.select(db.NO_OVERVIEW, is_dropdown=True)
        self.hmi.select(db.HOMESCREEN)
        self.hmi.verify_on_screen(db.CT100050)

        '''
        Steps:
         1. Select 'No Overview' from overview selection dropdown.
         2. Press to continue.

        Results:
         1. Keyphrase 'No Overview' appears in overview selection box.
         2. Detailed conveyor screen of the first conveyor in the system loads.
        '''

    def C3016701(self):
        '''HMI - ConveyorNeighbour - Navigation to conveyor screen from neighbouring conveyor'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.CONVEYOR_NEIGHBOUR)
        self.hmi.verify_on_screen(db.RT100007, critical=True)

        '''
        Steps:
         1. Select 'No Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select a port ID from the conveyor visual.

        Results:
         1. Keyphrase 'No Overview' appears in overview selection box.
         2. Detailed conveyor screen of the first conveyor in the system loads.
         3. Conveyor ID on detailed conveyor screen is identical to the port ID on the previous conveyor screen.
        '''
        
    def C3155527(self):
        '''HMI - CaseAccumMaster - Navigation to conveyor master screen from slave conveyor'''
        self._navigate_via_scrollbox_to_conveyor('RA500005_02')
        self.hmi.verify_on_screen(db.ACCUMULATION_DEFAULT, mask=db.ACCUMULATION_DEFAULT_MASK)
        self.hmi.select(db.MASTER_CONVEYOR)
        self.hmi.verify_on_screen(db.ACCUMULATION_MASTER_DEFAULT, mask=db.ACCUMULATION_MASTER_DEFAULT_MASK)
        
        '''
        Steps:
         1. Select 'No Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select a port ID from the conveyor visual.

        Results:
         1. Keyphrase 'No Overview' appears in overview selection box.
         2. Detailed conveyor screen of the first conveyor in the system loads.
         3. Conveyor ID on detailed conveyor screen is identical to the port ID on the previous conveyor screen.
        '''

    def C3016702(self):
        '''HMI - Elevator- Level navigation up'''
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self.hmi.verify_on_screen(db.ELEVATOR_SCREEN_DEFAULT, mask=db.ELEVATOR_SCREEN_DEFAULT_MASK)
        self.hmi.verify_on_screen(db.LOWER_LEVEL_SET)
        self.hmi.select(db.UP_ONE_LEVEL_SET)
        self.hmi.verify_on_screen(db.UPPER_LEVEL_SET, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select 'EL100132' from conveyor overview screen.
         5. Select up arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Detailed conveyor screen loads.
         5. Elevator display shifts upwards to show next three levels.
        '''

    def C3016703(self):
        '''HMI - Elevator- Level navigation down'''
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self.hmi.verify_on_screen(db.ELEVATOR_SCREEN_DEFAULT, mask=db.ELEVATOR_SCREEN_DEFAULT_MASK)
        self.hmi.select(db.UP_ONE_LEVEL_SET)
        self.hmi.verify_on_screen(db.UPPER_LEVEL_SET)
        self.hmi.select(db.DOWN_ONE_LEVEL_SET)
        self.hmi.verify_on_screen(db.LOWER_LEVEL_SET, critical=True)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select 'Elevator Loop' zone.
         4. Select 'EL100132' from conveyor overview screen.
         5. Select up arrow button at bottom of screen.
         6. Select down arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone overview screen loads.
         3. Specified zone screen loads.
         4. Detailed conveyor screen loads.
         5. Elevator display shifts upwards to show next three levels.
         6. Elevator display shifts back downwards to show lower three levels.
        '''

    def C3016704(self):
        '''HMI - TCar- Lane navigation right'''
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self.hmi.verify_on_screen(db.TCAR_SCREEN_DEFAULT, mask=db.TCAR_SCREEN_DEFAULT_MASK, critical=True)
        self.hmi.verify_on_screen(db.LEFT_LANE_SET)
        self.hmi.select(db.RIGHT_ONE_LANE_SET)
        self.hmi.verify_on_screen(db.RIGHT_LANE_SET, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'TC100635' in selection field.
         4. Select checkmark button.
         5. Select right arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TCar display shifts right to show next three lanes.
        '''

    def C3016705(self):
        '''HMI - TCar- Lane navigation left'''
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self.hmi.verify_on_screen(db.TCAR_SCREEN_DEFAULT, mask=db.TCAR_SCREEN_DEFAULT_MASK, critical=True)
        self.hmi.select(db.RIGHT_ONE_LANE_SET)
        self.hmi.verify_on_screen(db.RIGHT_LANE_SET)
        self.hmi.select(db.LEFT_ONE_LANE_SET)
        self.hmi.verify_on_screen(db.LEFT_LANE_SET, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'TC100635' in selection field.
         4. Select checkmark button.
         5. Select right arrow button at bottom of screen.
         6. Select left arrow button at bottom of screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TCar display shifts right to show next three lanes.
         6. TCar display shifts back left to show lower three lanes.
        '''

    def C3016706(self):
        '''HMI - SorterPhotoeye - Photoeye navigation up'''
        self._navigate_via_scrollbox_to_conveyor('U000008')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.UP_ONE_PHOTOEYE)
        self.hmi.verify_on_screen(db.PE_UPPER, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Photoeye' from menu.
         7. Select up arrow on right side of screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter photoeye screen loads.
         7. Photoeye number increments or switches to first photoeye of next sorter if no more photoeyes exist for current sorter.
        '''

    def C3016707(self):
        '''HMI - SorterPhotoeye - Photoeye navigation down'''
        self._navigate_via_scrollbox_to_conveyor('U000008')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.UP_ONE_PHOTOEYE)
        self.hmi.verify_on_screen(db.PE_UPPER)
        self.hmi.select(db.DOWN_ONE_PHOTOEYE)
        self.hmi.verify_on_screen(db.PE_UPPER, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Photoeye' from menu.
         7. Select down arrow on right side of screen.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter photoeye screen loads.
         7. Photoeye number decrements or switches to last photoeye of previous sorter if no more photoeyes exist for current sorter.
        '''
        
class ShutdownSequences(CommonPathwaysAndConfigurations):
 
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def C3016698(self):
        '''HMI - Shutdown - Complete HMI shutdown'''
        self.hmi.select(db.INITIATE_SHUTDOWN)
        self.hmi.verify_on_screen(db.SHUTDOWN_CONFIRMATION_POPUP)
        self.hmi.select(db.ACCEPT_SHUTDOWN, wait_time=3)
        if self.hmi.app.is_process_running():
            self._report_exception('Shutdown failed')
        
        '''
        Steps:
         1. Select power button from bottom of welcome screen.
         2. Select checkmark button to confirm shutdown.

        Results:
         1. Shutdown confirmation pop-up appears on screen.
         2. HMI application exits.
        '''
        
class ControlSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
    
    # To prevent drive runtime fault, breaks up the movement into multiple 10 second intervals
    def _elevator_move_to_position(self, position, button, timeout_all=60, timeout_stepped=5, exact=False):
        el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        start_time_stepped = time.time()
        curr_time = time.time()
        start_time = time.time()
            
        if exact:
            while((curr_time-start_time <= timeout_all) and el_pos != position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and el_pos != position):
                    curr_time = time.time()
                    el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                    
                if start_pos == el_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
        elif el_pos < position:
            while((curr_time-start_time <= timeout_all) and el_pos < position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and el_pos < position):
                    curr_time = time.time()
                    el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                    
                if start_pos == el_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
        else:
            while((curr_time-start_time <= timeout_all) and el_pos > position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and el_pos > position):
                    curr_time = time.time()
                    el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
                    
                if start_pos == el_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
    
    # To prevent drive runtime fault, breaks up the movement into multiple 10 second intervals
    def _tcar_move_to_position(self, position, button, timeout_all=60, timeout_stepped=5, exact=False):
        tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        start_time_stepped = time.time()
        curr_time = time.time()
        start_time = time.time()
            
        if exact:
            while((curr_time-start_time <= timeout_all) and tcar_pos != position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and tcar_pos != position):
                    curr_time = time.time()
                    tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                    
                if start_pos == tcar_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
        elif tcar_pos < position:
            while((curr_time-start_time <= timeout_all) and tcar_pos < position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and tcar_pos < position):
                    curr_time = time.time()
                    tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                    
                if start_pos == tcar_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
        else:
            while((curr_time-start_time <= timeout_all) and tcar_pos > position):
                self.hmi.press_selection(button)
                curr_time = time.time()
                start_time_stepped = time.time()
                start_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                while((curr_time-start_time_stepped <= timeout_stepped) and tcar_pos > position):
                    curr_time = time.time()
                    tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
                
                if start_pos == tcar_pos:
                    self._report_exception('Failed to move subsystem')
                    
                self.hmi.release_selection()
        
    def _home_elevator(self):
        if (self.hmi.exists(db.MANUAL_OFF)):
            self.hmi.select(db.MANUAL_OFF)
        
        if (self.hmi.exists(db.ASSISTED_MODE_OFF)):
            self.hmi.select(db.ASSISTED_MODE_OFF)
            
        el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)     
        if el_pos > 0:
            self._elevator_move_to_position(0, db.LINEAR_JOG_DOWN_FAST)
            
        elif el_pos < 0:
            self._elevator_move_to_position(0, db.LINEAR_JOG_UP)
        
        el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        if(el_pos != 0):
            self._report_exception('Failed to home subsystem')
            
        self.hmi.select(db.ASSISTED_MODE_ON)
        self.hmi.select(db.MANUAL_ON)
        
    def _home_tcar(self):
        timeout = 60
        if (self.hmi.exists(db.MANUAL_OFF)):
            self.hmi.select(db.MANUAL_OFF)
        
        if (self.hmi.exists(db.ASSISTED_MODE_OFF)):
            self.hmi.select(db.ASSISTED_MODE_OFF)
            
        tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        if tcar_pos > 0:
            self._tcar_move_to_position(0, db.LINEAR_JOG_LEFT_FAST)
            
        elif tcar_pos < 0:
            self._tcar_move_to_position(0, db.LINEAR_JOG_RIGHT)
        
        tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        if(tcar_pos != 0):
            self._report_exception('Failed to home subsystem')
            
        self.hmi.select(db.ASSISTED_MODE_ON)
        self.hmi.select(db.MANUAL_ON, wait_time=1)
    
    def C3016657(self):
        '''HMI - Control - Manual slow linear jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        motor_on = self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogForward')
        if motor_on:
            self._report_exception('Motor on prior to linear jogging')
        
        self.hmi.press_selection(db.LINEAR_JOG_RIGHT)
        time.sleep(3)
        motor_on = self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogForward')
        motor_fast =self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogFastSpeed')
        
        if not motor_on:
            self._report_exception('Motor not on during linear jogging')
            
        if motor_fast:
            self._report_exception('Motor not running in slow mode')
        
        self.hmi.release_selection()
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Hold slow mode linear jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Button changes to activated mode visual.
        '''

    def C3016658(self):
        '''HMI - Control - Manual fast linear jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        motor_on = self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogForward')
        if motor_on:
            self._report_exception('Motor on prior to fast linear jogging')
        
        self.hmi.press_selection(db.LINEAR_JOG_RIGHT_FAST)
        time.sleep(3)
        motor_on = self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogForward')
        motor_fast =self.plc.get_plc_signal('Hmi.interface[1].control.selected.port12Motor.jogFastSpeed')
        
        if not motor_on:
            self._report_exception('Motor not on during fast linear jogging')
            
        if not motor_fast:
            self._report_exception('Motor not running in fast mode')

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Hold fast mode linear jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Button changes to activated mode visual.
        '''

    def C3016659(self):
        '''HMI - Control - Manual slow linear service mode jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        service_mode_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.conveyorModeService')
        if service_mode_on:
            self._report_exception('Service mode active prior to activation')
            
        self.hmi.select(db.SERVICE_MODE_OFF)
        self.hmi.verify_on_screen(db.SERVICE_MODE_ON, critical=True)

        self.hmi.select(db.SERVICE_MODE_LINEAR_JOG_RIGHT_OFF)
        self.hmi.verify_on_screen(db.SERVICE_MODE_LINEAR_JOG_RIGHT_ON, critical=True)
        
        service_mode_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.conveyorModeService')
        service_mode_slow = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.port12LatchedJog.forwardSlow')
        
        if not service_mode_on:
            self._report_exception('Service mode inactive subsequent to activation')
            
        if not service_mode_slow:
            self._report_exception('Service mode not running in slow mode')
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Place TU onto conveyor
         6. Select manual button.
         7. Select service mode button.
         8. Select slow mode  forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU occupancy visual appears over conveyor visual.
         6. Conveyor screen switches to manual view.
         7. Conveyor screen switches to service mode view.
         8. Button changes to activated mode visual.     Conveyor continuously jogs.
        '''

    def C3016660(self):
        '''HMI - Control - Manual fast linear service mode jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        service_mode_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.conveyorModeService')
        if service_mode_on:
            self._report_exception('Service mode active prior to activation')
            
        self.hmi.select(db.SERVICE_MODE_OFF)
        self.hmi.verify_on_screen(db.SERVICE_MODE_ON, critical=True)
        self.hmi.select(db.SERVICE_MODE_LINEAR_JOG_RIGHT_FAST_OFF)
        self.hmi.verify_on_screen(db.SERVICE_MODE_LINEAR_JOG_RIGHT_FAST_ON, critical=True)
        
        service_mode_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.conveyorModeService')
        service_mode_fast = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.port12LatchedJog.forwardFast')
        
        if not service_mode_on:
            self._report_exception('Service mode inactive subsequent to activation')
            
        if not service_mode_fast:
            self._report_exception('Service mode not running in fast mode')
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Place TU onto conveyor
         6. Select manual button.
         7. Select service mode button.
         8. Select fast mode forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU occupancy visual appears over conveyor visual.
         6. Conveyor screen switches to manual view.
         7. Conveyor screen switches to service mode view.
         8. Button changes to activated mode visual.     Conveyor continuously jogs.
        '''

    def C3016664(self):
        '''HMI - Control -  Linear jogging with photoeye bypass enabled'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        bypass_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensorBypassActive')
        if bypass_on:
            self._report_exception('Bypass active prior to activation')
        
        self.hmi.select(db.PHOTOEYE_BYPASS_OFF)
        self.hmi.verify_on_screen(db.PHOTOEYE_BYPASS_ON, critical=True)
        
        #Extend to jog beyond PE to determine is bypass works
        #self.hmi.select(db.LINEAR_JOG_RIGHT_FAST, duration=3)
        
        bypass_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensorBypassActive')
        if not bypass_on:
            self._report_exception('Bypass inactive subsequent to activation')
            
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter an infeed conveyor name in selection field.
         4. Select checkmark button.
         5. Place TU onto conveyor
         6. Select manual button.
         7. Select photoeye bypass button.
         8. Hold fast mode backward jogging button.
         9. Hold slow mode backward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU occupancy visual appears over conveyor visual.
         6. Conveyor screen switches to manual view.
         7. Conveyor screen photoeye bypass button turns blue.
         8. No change given that bypass is only compatible with slow jogging mode.
         9. Button changes to activated mode visual.     In port PE occupied visual turns off after a medium length period.
        '''

    def C3016665(self):
        '''HMI - Control - Manual slow rotational jogging'''
        self._navigate_via_scrollbox_to_conveyor('RX100200')
        self.hmi.verify_on_screen(db.TURNTABLE_DEFAULT, mask=db.TURNTABLE_DEFAULT_MASK)
        
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.verify_on_screen(db.TURNTABLE_INITIAL, mask=db.TURNTABLE_ROTATION_MASK)
        
        timeout = 80
        print("BEFORE: " + self.plc.get_plc_signal('Hmi.interface[1].control.selected.rotationMotor.jogCcw'), flush=True)
        self.hmi.press_selection(db.ROTATE_ANTICLOCKWISE)
        #Just for debug
        time.sleep(1)
        print("AFTER" + self.plc.get_plc_signal('Hmi.interface[1].control.selected.rotationMotor.jogCcw'), flush=True)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK, critical=True)
            
        self.hmi.press_selection(db.ROTATE_CLOCKWISE)
        time.sleep(10)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK, critical=True)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100200' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Hold slow mode rotational jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Button changes to activated mode visual.     Conveyor screen displays turntable in rotated orientation after medium length period.
        '''

    def C3016666(self):
        '''HMI - Control - Manual fast rotational jogging'''
        self._navigate_via_scrollbox_to_conveyor('RX100200')
        self.hmi.verify_on_screen(db.TURNTABLE_DEFAULT, mask=db.TURNTABLE_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.verify_on_screen(db.TURNTABLE_INITIAL, mask=db.TURNTABLE_ROTATION_MASK)
        
        timeout = 40
        print("BEFORE: " + self.plc.get_plc_signal('Hmi.interface[1].control.selected.rotationMotor.jogCcw'), flush=True)
        self.hmi.press_selection(db.ROTATE_ANTICLOCKWISE_FAST)
        
        #Just for debug
        time.sleep(1)
        print("AFTER: " + self.plc.get_plc_signal('Hmi.interface[1].control.selected.rotationMotor.jogCcw'), flush=True)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK, critical=True)
            
        self.hmi.press_selection(db.ROTATE_CLOCKWISE_FAST)
        time.sleep(5)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.TURNTABLE_FINAL, mask=db.TURNTABLE_ROTATION_MASK, critical=True)

        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100200' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Hold fast mode rotational jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Button changes to activated mode visual.     Conveyor screen displays turntable in rotated orientation after short length period.
        '''

    def C3016667(self):
        '''HMI - Control - Manual lift jogging'''
        self._navigate_via_scrollbox_to_conveyor('RX100510')
        self.hmi.verify_on_screen(db.LIFT_TABLE_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.LIFT_TABLE_MANUAL_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK)
        
        timeout = 10
        self.hmi.press_selection(db.LINEAR_JOG_DOWN, search_region=self.lift_button_region)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.LIFT_TABLE_DOWN)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.LIFT_TABLE_DOWN, critical=True)
        
        self.hmi.press_selection(db.LINEAR_JOG_UP, search_region=self.lift_button_region)
        curr_time = time.time()
        start_time = time.time()
        while((curr_time-start_time <= timeout) and not self.hmi.exists(db.LIFT_TABLE_UP)):
            curr_time = time.time()
        self.hmi.release_selection()
        self.hmi.verify_on_screen(db.LIFT_TABLE_UP, critical=True)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'RX100510' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Hold lift  upward jogging button.
         7. Hold lift downward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Button changes to activated mode visual.     Lift proximity up visual turns on after medium length period.
         7. Button changes to activated mode visual.     Lift proximity up visual turns off and proximity down turns on after medium length period.
        '''
    
    def C3016668(self):
        '''HMI - Control - Manual assisted elevator jogging''' 
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self._home_elevator()
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.LINEAR_JOG_DOWN, duration=3)
        el_neg = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        if el_neg != 0:
            self._report_exception('Assisted elevator jogging into the negative')
       
        el_pos_0 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_UP, duration=3)
        el_pos_1 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_UP_FAST, duration=3)
        el_pos_2 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_DOWN_FAST, duration=3)
        el_pos_3 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_DOWN, duration=3)
        el_pos_4 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        
        # Critical comparisons
        r1 = el_pos_1 > el_pos_0
        r2 = el_pos_2 > el_pos_1
        r3 = el_pos_3 < el_pos_2
        r4 = el_pos_4 < el_pos_3
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if not (r1 and r2 and r3 and r4):
            failed_evaluations = ''
            if not r1:
                failed_evaluations += '\nElevator position 1: %d > Elevator position 0: %d' % (el_pos_1, el_pos_0)
            if not r2:
                failed_evaluations += '\nElevator position 2: %d > Elevator position 1: %d' % (el_pos_2, el_pos_1)
            if not r3:
                failed_evaluations += '\nElevator position 3: %d < Elevator position 2: %d' % (el_pos_3, el_pos_2)
            if not r4:
                failed_evaluations += '\nElevator position 4: %d < Elevator position 3: %d' % (el_pos_4, el_pos_3)
                
            self._report_exception('At least one numerical evaluation failed:' + failed_evaluations)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'EL100132' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle on Assisted Jogging button.
         7. Hold elevator upward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Confirms selection of assisted jogging mode.
         7. Current elevator position increases.
        '''
        
    def C3016669(self):
        '''HMI - Control - Manual unassisted elevator jogging'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self._home_elevator()
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ASSISTED_MODE_ON, wait_time=1)
        
        el_target = self.hmi.read_region(self.elevator_target_position_region, **self.read_numbers_config)
        if el_target != -999:
            self.hmi.select(db.MANUAL_ON)
            self.hmi.verify_on_screen(db.MANUAL_OFF)
            self._report_exception('Unassisted elevator target position not set as expected')
       
        self.hmi.select(db.LINEAR_JOG_DOWN, duration=0.4)
        el_pos_0 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        if el_pos_0 >= 0:
            self.hmi.select(db.MANUAL_ON)
            self.hmi.verify_on_screen(db.MANUAL_OFF)
            self._report_exception('Unassisted elevator not jogging into the negative')
        
        self.hmi.select(db.LINEAR_JOG_UP, duration=4)
        el_pos_1 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_UP_FAST, duration=3)
        el_pos_2 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_DOWN_FAST, duration=3)
        el_pos_3 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_DOWN, duration=3)
        el_pos_4 = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        
        # Critical comparisons
        r1 = el_pos_1 > el_pos_0
        r2 = el_pos_2 > el_pos_1
        r3 = el_pos_3 < el_pos_2
        r4 = el_pos_4 < el_pos_3
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if not (r1 and r2 and r3 and r4):
            failed_evaluations = ''
            if not r1:
                failed_evaluations += '\nElevator position 1: %d > Elevator position 0: %d' % (el_pos_1, el_pos_0)
            if not r2:
                failed_evaluations += '\nElevator position 2: %d > Elevator position 1: %d' % (el_pos_2, el_pos_1)
            if not r3:
                failed_evaluations += '\nElevator position 3: %d < Elevator position 2: %d' % (el_pos_3, el_pos_2)
            if not r4:
                failed_evaluations += '\nElevator position 4: %d < Elevator position 3: %d' % (el_pos_4, el_pos_3)
                
            self._report_exception('At least one numerical evaluation failed:' + failed_evaluations)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'EL100132' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle off Assisted Jogging button.
         7. Hold elevator upward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Switches to unassisted jogging mode.
         7. Current elevator position increases.
        '''
    
    def C3016670(self):
        '''HMI - Control - Manual assisted elevator fine positioning'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('EL100132')
        self._home_elevator()
        self.hmi.select(db.MANUAL_OFF)
        
        timeout = 20       
        el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_UP, duration=0.5, wait_time=1)
        el_target = self.hmi.read_region(self.elevator_target_position_region, **self.read_numbers_config)
        undershoot_target = el_target-400
        
        self._elevator_move_to_position(undershoot_target, db.LINEAR_JOG_UP_FAST)
        self._elevator_move_to_position(el_target, db.LINEAR_JOG_UP, exact=True)
        
        el_pos = self.hmi.read_region(self.elevator_current_position_region, **self.read_numbers_config)
        el_target_level = self.hmi.read_region(self.elevator_target_level_region, **self.read_numbers_config)
        el_current_level = self.hmi.read_region(self.elevator_current_level_region, **self.read_numbers_config)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if(el_pos != el_target or el_target_level != el_current_level):
            self._report_exception('At least one numerical evaluation failed:\nExpected Position: %d, Current Position: %d\nExpected Level: %d, Current Level: %d' % (el_target, el_pos, el_target_level, el_current_level))

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'EL100132' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle on Assisted Jogging button.
         7. Hold elevator slow upward jogging button until current level not equal to '-' (Default value).

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Confirms selection of assisted jogging mode.
         7. Current level reading is '1' and has been achieved before timeout.     Position has not overshot or undershot level 1 defined position.
        '''

    def C3016671(self):
        '''HMI - Control - Manual assisted tcar jogging'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self._home_tcar()
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.LINEAR_JOG_LEFT, duration=3)
        tc_neg = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        if tc_neg != 0:
            self.hmi.select(db.MANUAL_ON)
            self.hmi.verify_on_screen(db.MANUAL_OFF)
            self._report_exception('Assisted tcar jogging into the negative')
       
        tc_pos_0 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_RIGHT, duration=3)
        tc_pos_1 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_RIGHT_FAST, duration=3)
        tc_pos_2 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_LEFT_FAST, duration=3)
        tc_pos_3 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_LEFT, duration=3)
        tc_pos_4 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        
        # Critical comparisons
        r1 = tc_pos_1 > tc_pos_0
        r2 = tc_pos_2 > tc_pos_1
        r3 = tc_pos_3 < tc_pos_2
        r4 = tc_pos_4 < tc_pos_3
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if not (r1 and r2 and r3 and r4):
            failed_evaluations = ''
            if not r1:
                failed_evaluations += '\nTCar position 1: %d > TCar position 0: %d' % (tc_pos_1, tc_pos_0)
            if not r2:
                failed_evaluations += '\nTCar position 2: %d > TCar position 1: %d' % (tc_pos_2, tc_pos_1)
            if not r3:
                failed_evaluations += '\nTCar position 3: %d < TCar position 2: %d' % (tc_pos_3, tc_pos_2)
            if not r4:
                failed_evaluations += '\nTCar position 4: %d < TCar position 3: %d' % (tc_pos_4, tc_pos_3)
                
            self._report_exception('At least one numerical evaluation failed:' + failed_evaluations)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'TC100635' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle on Assisted Jogging button.
         7. Hold tcar forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Confirms selection of assisted jogging mode.
         7. Current tcar position increases.
        '''

    def C3016672(self):
        '''HMI - Control - Manual unassisted tcar jogging'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self._home_tcar()
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ASSISTED_MODE_ON, wait_time=1)
        
        tcar_target = self.hmi.read_region(self.tcar_target_position_region, **self.read_numbers_config)
        if tcar_target != -999:
            self.hmi.select(db.MANUAL_ON)
            self.hmi.verify_on_screen(db.MANUAL_OFF)
            self._report_exception('Unassisted tcar target position not set as expected')
            
        self.hmi.select(db.LINEAR_JOG_LEFT, duration=0.4)
        tc_pos_0 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        if tc_pos_0 >= 0:
            self.hmi.select(db.MANUAL_ON)
            self.hmi.verify_on_screen(db.MANUAL_OFF)
            self._report_exception('Unassisted tcar not jogging into the negative')
       
        self.hmi.select(db.LINEAR_JOG_RIGHT, duration=4)
        tc_pos_1 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_RIGHT_FAST, duration=3)
        tc_pos_2 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_LEFT_FAST, duration=3)
        tc_pos_3 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_LEFT, duration=3)
        tc_pos_4 = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        
        # Critical comparisons
        r1 = tc_pos_1 > tc_pos_0
        r2 = tc_pos_2 > tc_pos_1
        r3 = tc_pos_3 < tc_pos_2
        r4 = tc_pos_4 < tc_pos_3
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if not (r1 and r2 and r3 and r4):
            failed_evaluations = ''
            if not r1:
                failed_evaluations += '\nTCar position 1: %d > TCar position 0: %d' % (tc_pos_1, tc_pos_0)
            if not r2:
                failed_evaluations += '\nTCar position 2: %d > TCar position 1: %d' % (tc_pos_2, tc_pos_1)
            if not r3:
                failed_evaluations += '\nTCar position 3: %d < TCar position 2: %d' % (tc_pos_3, tc_pos_2)
            if not r4:
                failed_evaluations += '\nTCar position 4: %d < TCar position 3: %d' % (tc_pos_4, tc_pos_3)
                
            self._report_exception('At least one numerical evaluation failed:' + failed_evaluations)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'TC100635' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle off Assisted Jogging button.
         7. Hold tcar forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Switches to unassisted jogging mode.
         7. Current tcar position increases.
        '''

    def C3016673(self):
        '''HMI - Control - Manual assisted tcar fine positioning'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires updated emulation')
        return True
        
        self._navigate_via_scrollbox_to_conveyor('TC100635')
        self._home_tcar()
        self.hmi.select(db.MANUAL_OFF)
        
        timeout = 40       
        tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        self.hmi.select(db.LINEAR_JOG_RIGHT, duration=0.5, wait_time=1)
        tcar_target = self.hmi.read_region(self.tcar_target_position_region, **self.read_numbers_config)
        undershoot_target = tcar_target-400
        
        self._tcar_move_to_position(undershoot_target, db.LINEAR_JOG_RIGHT_FAST)
        self._tcar_move_to_position(tcar_target, db.LINEAR_JOG_RIGHT, exact=True)
        
        tcar_pos = self.hmi.read_region(self.tcar_current_position_region, **self.read_numbers_config)
        tcar_target_lane = self.hmi.read_region(self.tcar_target_lane_region, **self.read_numbers_config)
        tcar_current_lane = self.hmi.read_region(self.tcar_current_lane_region, **self.read_numbers_config)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if(tcar_pos != tcar_target or tcar_current_lane != tcar_target_lane):
            self._report_exception('At least one numerical evaluation failed:\nExpected Position: %d, Current Position: %d\nExpected Level: %d, Current Level: %d' % (tcar_target, tcar_pos, tcar_target_level, tcar_current_level))

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'TC100635' in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Toggle on Assisted Jogging button.
         7. Hold tcar slow forward jogging button until current lane not equal to '-' (Default value).

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Confirms selection of assisted jogging mode.
         7. Current lane reading is '1' and has been achieved before timeout.     Position has not overshot or undershot lane 1 defined position.
        '''

    def C3016674(self):
        '''HMI - Control - SorterCommon inhibit'''
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_SORTER_SCREEN)
         
        self.hmi.select(db.INHIBIT_COMMUNICATIONS_ON, critical=False)
            
        self.hmi.verify_on_screen(db.SORTER_COMMON, mask=db.SORTER_COMMON_MASK)        
        self.hmi.verify_on_screen(db.SORTER_COMMON_UNINHIBITTED, critical=True)
        self.hmi.select(db.INHIBIT_COMMUNICATIONS_OFF)
        self.hmi.verify_on_screen(db.SORTER_COMMON_INHIBITTED, critical=True)
        self.hmi.select(db.INHIBIT_COMMUNICATIONS_ON)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000005' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Sorter'from menu.
         7. Select inhibit WCS connection button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter common screen loads.
         7. Inhibit button turns blue.     Inhibit indicator box toggles on.
        '''

    def C3016675(self):
        '''HMI - Control - SorterDivert inhibit'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_DIVERT_SCREEN)
        self.hmi.select(db.SORTER_STATUS_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_DIVERT_STATUS_TAB, mask=db.SORTER_DIVERT_STATUS_TAB_MASK)
        self.hmi.verify_on_screen(db.SORTER_DIVERT_UNINHIBITTED, critical=True)
        self.hmi.select(db.INHIBIT_OFF)
        self.hmi.verify_on_screen(db.SORTER_DIVERT_INHIBITTED, critical=True)
        self.hmi.select(db.INHIBIT_ON)
    
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Divert' from menu.
         7. Select 'Status' tab.
         8. Select inhibit button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter divert screen loads.
         7. Switches to the selected tab.
         8. Inhibit button turns blue.     Inhibit indicator box toggles on.
        '''

    def C3016676(self):
        '''HMI - Control - SorterInduct control'''
        self._navigate_via_scrollbox_to_conveyor('U000005')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_INDUCT_SCREEN)
        self.hmi.select(db.SORTER_CONTROL_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_INDUCT_CONTROL_TAB, mask=db.SORTER_INDUCT_CONTROL_TAB_MASK)
        self.hmi.select(db.INHIBIT_OFF)
        self.hmi.select(db.PURGE_ENABLE_OFF)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.SORTER_INDUCT_ALL_CONTROLS_ACTIVE, min_confidence=0.99, critical=True)
        self.hmi.select(db.INHIBIT_ON)
        self.hmi.select(db.PURGE_ENABLE_ON)
        self.hmi.select(db.MANUAL_ON)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000005' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Induct' from menu.
         7. Select 'Control' tab.
         8. Select disable button.
         9. Select purge button.
         10. Select manual button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter induct screen loads.
         7. Switches to the selected tab.
         8. Disable button turns blue.     Enable indicator box toggles off.
         9. Purge button turns blue.      Purge enable indicator box toggles on.
         10. Manual button turns blue.     Manual input field highlights.
        '''

    def C3016677(self):
        '''HMI - Control - SorterPhotoeye train single'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.SORTER_TRAINING_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_TRAINING_TAB, mask=db.SORTER_PHOTOEYE_TRAINING_TAB_MASK)
        self.hmi.select(db.EDIT_TRAINING_SETTINGS_OFF, search_region=self.train_single_photoeye_region)
        
        if self.hmi.exists(db.LOGIN_POPUP, mask=db.LOGIN_POPUP_MASK):
            self.hmi.select(db.USERNAME_BOX, mask=db.USERNAME_BOX_MASK)
            self.hmi.virtual_keyboard_write("Administrator")
            self.hmi.select(db.PASSWORD_BOX, mask=db.PASSWORD_BOX_MASK)
            self.hmi.virtual_keyboard_write("dematic")
            self.hmi.select(db.LOGIN_OK)
            self.hmi.select(db.EDIT_TRAINING_SETTINGS_OFF, search_region=self.train_single_photoeye_region)
            
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_TRAIN_SINGLE, mask=db.SORTER_PHOTOEYE_TRAIN_MASK, critical=True)
        self.hmi.select(db.EDIT_TRAINING_SETTINGS_ON, search_region=self.train_single_photoeye_region)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Photoeye' from menu.
         7. Select 'Training' tab.
         8. Select train single button.
         9. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter photoeye screen loads.
         7. Switches to the selected tab.
         8. Train single button turns blue.     Checkmark appears.
         9. Actual training position set's to 9999999 for the specified photoeye.
        '''

    def C3016678(self):
        '''HMI - Control - SorterPhotoeye train all'''
        self._navigate_via_scrollbox_to_conveyor('U000009')
        self.hmi.select(db.OPEN_DEVICE_LIST)
        self.hmi.verify_on_screen(db.DEVICE_LIST_POPUP, mask=db.DEVICE_LIST_POPUP_MASK)
        self.hmi.select(db.SWITCH_TO_PHOTOEYE_SCREEN)
        self.hmi.select(db.SORTER_TRAINING_TAB_BUTTON)
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_TRAINING_TAB, mask=db.SORTER_PHOTOEYE_TRAINING_TAB_MASK)
        self.hmi.select(db.EDIT_TRAINING_SETTINGS_OFF, search_region=self.train_all_photoeye_region)
        
        if self.hmi.exists(db.LOGIN_POPUP, mask=db.LOGIN_POPUP_MASK):
            self.hmi.select(db.USERNAME_BOX, mask=db.USERNAME_BOX_MASK)
            self.hmi.virtual_keyboard_write("Administrator")
            self.hmi.select(db.PASSWORD_BOX, mask=db.PASSWORD_BOX_MASK)
            self.hmi.virtual_keyboard_write("dematic")
            self.hmi.select(db.LOGIN_OK)
            self.hmi.select(db.EDIT_TRAINING_SETTINGS_OFF, search_region=self.train_all_photoeye_region)
            
        self.hmi.verify_on_screen(db.SORTER_PHOTOEYE_TRAIN_ALL, mask=db.SORTER_PHOTOEYE_TRAIN_MASK, critical=True)
        self.hmi.select(db.EDIT_TRAINING_SETTINGS_ON, search_region=self.train_all_photoeye_region)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter 'U000009' in selection field.
         4. Select checkmark button.
         5. Select expand devices button.
         6. Select 'Photoeye' from menu.
         7. Select 'Training' tab.
         8. Select train all button.
         9. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Device selection menu appears.
         6. Sorter photoeye screen loads.
         7. Switches to the selected tab.
         8. Train all button turns blue.     Checkmark appears.
         9. Actual training position set's to 9999999 for all sorter photoeyes.
        '''

    def C3016679(self):
        '''HMI - Control - Alarm/Fault acknowledge'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU_DATA, wait_time=1)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.DELETE_TU_DATA)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.verify_on_screen(db.TU_DATA_ERROR, critical=True)
        self.hmi.select(db.FAULT_RESET, wait_time=1)
        
        if self.hmi.exists(db.TU_DATA_ERROR):
            self._report_exception('Alarm acknowledge failed')

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Alarms' from menu.
         3. Select fault acknowledge button.

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Alarm screen loads.
         3. Removes acknowledged faults from alarm list.
        '''

    def C3020412(self):
        '''HMI - Control -  Linked conveyor slow linear jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        linked_right_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort2.portLinkActive')
        linked_left_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort1.portLinkActive')
        if linked_left_on or linked_right_on:
            self._report_exception('Conveyors linked prior to linking')
            
        self.hmi.select(db.LINKED_CONVEYOR_OFF, search_region=self.right_controls_region)
        self.hmi.verify_on_screen(db.LINKED_CONVEYOR_ON, search_region=self.right_controls_region)
        self.hmi.select(db.LINKED_CONVEYOR_OFF, search_region=self.left_controls_region)
        self.hmi.verify_on_screen(db.LINKED_CONVEYOR_ON, search_region=self.left_controls_region)
        
        linked_right_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort2.portLinkActive')
        linked_left_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort1.portLinkActive')
        if (not linked_left_on) or (not linked_right_on):
            self._report_exception('Conveyors not linked subsequent to linking')

        # Check linked conveyors speed to ensure operation at slow speed
            
        self.hmi.select(db.LINKED_CONVEYOR_ON, search_region=self.right_controls_region)
        self.hmi.select(db.LINKED_CONVEYOR_ON, search_region=self.left_controls_region)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Place TU onto conveyor
         6. Select manual button.
         7. Select linking buttons.
         8. Hold slow mode forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU occupancy visual appears over conveyor visual.
         6. Conveyor screen switches to manual view.
         7. Conveyor screen linking symbols turn blue.
         8. Button changes to activated mode visual.     Out port PE occupied visual turns off after a medium length period.
        '''

    def C3020413(self):
        '''HMI - Control -  Linked conveyor fast linear jogging'''
        self._navigate_via_scrollbox_to_conveyor('RT100010')
        self.hmi.verify_on_screen(db.STRAIGHT_TRANSPORT_DEFAULT, mask=db.STRAIGHT_TRANSPORT_DEFAULT_MASK)
        self.hmi.select(db.MANUAL_OFF)
        
        linked_right_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort2.portLinkActive')
        linked_left_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort1.portLinkActive')
        if linked_left_on or linked_right_on:
            self._report_exception('Conveyors linked prior to linking')
            
        self.hmi.select(db.LINKED_CONVEYOR_OFF, search_region=self.right_controls_region)
        self.hmi.verify_on_screen(db.LINKED_CONVEYOR_ON, search_region=self.right_controls_region)
        self.hmi.select(db.LINKED_CONVEYOR_OFF, search_region=self.left_controls_region)
        self.hmi.verify_on_screen(db.LINKED_CONVEYOR_ON, search_region=self.left_controls_region)
        
        linked_right_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort2.portLinkActive')
        linked_left_on = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.statusPort1.portLinkActive')
        if (not linked_left_on) or (not linked_right_on):
            self._report_exception('Conveyors not linked subsequent to linking')

        # Check linked conveyors speed to ensure operation at fast speed
            
        self.hmi.select(db.LINKED_CONVEYOR_ON, search_region=self.right_controls_region)
        self.hmi.select(db.LINKED_CONVEYOR_ON, search_region=self.left_controls_region)
        
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Place TU onto conveyor
         6. Select manual button.
         7. Select linking buttons.
         8. Hold fast mode forward jogging button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. TU occupancy visual appears over conveyor visual.
         6. Conveyor screen switches to manual view.
         7. Conveyor screen linking symbols turn blue.
         8. Button changes to activated mode visual.     Out port PE occupied visual turns off after a short length period.
        '''

    def C3020414(self):
        '''HMI - Control - Manual add TU'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.verify_on_screen(db.TU_OCCUPANCY, mask=db.TU_OCCUPANCY_MASK, critical=True)
        
        self.hmi.select(db.REMOVE_TU)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Select add TU button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Conveyor screen displays TU on conveyor.
        '''

    def C3020415(self):
        '''HMI - Control - Manual add TU data'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU_DATA, wait_time=1)
        field_unpopulated = self.hmi.exists(db.EMPTY_TU_DATA)
        
        #read data text here (Requires better OCR)
        
        self.hmi.select(db.DELETE_TU_DATA)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.MANUAL_OFF)
        
        if field_unpopulated:
            self._report_exception('Failed to populate data fields time')
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter a transport conveyor name in selection field.
         4. Select checkmark button.
         5. Select manual button.
         6. Select add TU Data button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Conveyor screen TU data fields get populated.
        '''
        
    def C3187247(self):
        '''HMI - Control - Edit TU data fields without confirmation'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.ADD_TU_DATA)
        self.hmi.select(db.EDIT_TU_DATA_OFF)
        
        self.hmi.select_point(self.tu_data_field_click_point)
        self.hmi.virtual_numpad_write('10')
        number = self.hmi.read_clipboard()
        if number != '10':
            self.hmi.select(db.MANUAL_ON)
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('10', number))
            
        self.hmi.select(db.EDIT_TU_DATA_ON)
        new_number = self.hmi.read_region(self.tu_data_field_region, **self.read_numbers_config)
        self.hmi.select(db.MANUAL_ON)
        if new_number != 0:
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('0', str(new_number)))
        
    def C3187248(self):
        '''HMI - Control - Confirm TU data edits'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.ADD_TU_DATA)
        self.hmi.select(db.EDIT_TU_DATA_OFF)
        
        self.hmi.select_point(self.tu_data_field_click_point)
        self.hmi.virtual_numpad_write('10')
        number = self.hmi.read_clipboard()
        if number != '10':
            self.hmi.select(db.MANUAL_ON)
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('10', number))
            
        self.hmi.select(db.CONFIRM_TU_DATA_EDITS, wait_time=1)
        new_number = self.hmi.read_region(self.tu_data_field_region, **self.read_numbers_config)
        self.hmi.select(db.MANUAL_ON)
        if new_number != 10:
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('10', str(new_number)))
        
    def C3187249(self):
        '''HMI - Control - Fault checkbox interaction '''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.TU_INFO_CONVEYOR_TAB_BUTTON)
        self.hmi.select(db.ADD_TU_DATA)
        self.hmi.select(db.EDIT_TU_DATA_OFF)
        self.hmi.select(db.CHECKBOX_OFF, search_region=self.tu_data_checkbox_region)
        self.hmi.verify_on_screen(db.CHECKBOX_ON, min_confidence=0.95, search_region=self.tu_data_checkbox_region, critical=True)
        #Click one of the checkboxes
        #Validate that it changes to other colour

class StaticDataSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def _static_write_number(self, input):
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.TU_INFO)
        self.hmi.select(db.ADD_TU_DATA)
        self.hmi.select(db.EDIT_TU_DATA_OFF)
        self.hmi.select_point(self.tu_data_field_click_point)
        self.hmi.virtual_numpad_write(input)

    def C3017931(self):
        '''HMI - ECC - Minimum decimal'''
        self._static_write_number('0')
        number = self.hmi.read_clipboard()
        self.hmi.select(db.MANUAL_ON)
        if number != '0':
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('0', number))

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Change ECC number through HMI-&gt;interface[1]-&gt;control-&gt;selected-&gt;pncg-&gt;selectedEcc to 0

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. ![](index.php?/attachments/get/643ebb92-40ac-47cd-97e0-9aa4abbce41b)
        '''

    def C3017932(self):
        '''HMI - ECC - Maximum decimal'''
        self._static_write_number('9999')
        if self.hmi.read_clipboard() != '9999':
            self.hmi.select(db.MANUAL_ON)
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('9999', number))
        
        self.hmi.select_point(self.tu_data_field_click_point)
        self.hmi.virtual_numpad_write('10000')  
        number = self.hmi.read_clipboard()  
        self.hmi.select(db.MANUAL_ON)        
        if number != '####':
            self._report_exception('Failed evaluation\nExpected: %s, Found: %s' % ('####', str(number)))

        '''
        Steps:
         1. Select slide menu button from top banner.
         2. Select 'Diagnostics' from menu.
         3. Select 'PNCG' button.
         4. Select checkmark button.
         5. Select 'ECC' button.
         6. Change ECC number through HMI-&gt;interface[1]-&gt;control-&gt;selected-&gt;pncg-&gt;selectedEcc to 255

        Results:
         1. Menu slides in from left side of welcome screen.
         2. Diagnostics screen loads.
         3. PNCG screen loads.
         4. Confirms selection of PNCG.
         5. ECC screen loads.
         6. ![](index.php?/attachments/get/e5e3951e-2533-4759-a419-a019ca9c1938)
        '''

    def C3187245(self):
        '''HMI - Numerical Field - Negative maximum'''
        self._static_write_number('-999')
        if self.hmi.read_clipboard() != '-999':
            self.hmi.select(db.MANUAL_ON)
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('-999', number))
        
        self.hmi.select_point(self.tu_data_field_click_point)
        self.hmi.virtual_numpad_write('-1000')  
        number = self.hmi.read_clipboard()  
        self.hmi.select(db.MANUAL_ON)        
        if number != '####':
            self._report_exception('Failed numerical evaluation\nExpected: %s, Found: %s' % ('####', number))
            
    def C3017937(self):
        '''HMI - ConveyorVisual - Roller'''
        self._navigate_via_scrollbox_to_conveyor('RT100005')
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        res = self.hmi.exists(db.ROLLER_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK, min_confidence=0.95) or self.hmi.exists(db.ROLLER_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK, min_confidence=0.95)
        
        if not res:
            self.hmi.get_comparison_summary(db.ROLLER_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            self.hmi.get_comparison_summary(db.ROLLER_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            
            error_str = os.path.basename(db.ROLLER_CONVEYOR_HORIZONTAL).split('.')[0].upper() + ' nor ' + os.path.basename(db.ROLLER_CONVEYOR_VERTICAL).split('.')[0].upper()
            self.hmi.add_comment('Error! Image not found: ' + error_str)
            raise ImageNotFoundError(error_str)
            
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor with 'R' conveyor ID prefix in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/abbdb86a-5bf9-408a-8daf-9c4acd518055)
        '''

    def C3017938(self):
        '''HMI - ConveyorVisual - Chain'''
        self._navigate_via_scrollbox_to_conveyor('CT100050')
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        res = self.hmi.exists(db.CHAIN_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK) or self.hmi.exists(db.CHAIN_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
        
        if not res:
            self.hmi.get_comparison_summary(db.CHAIN_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            self.hmi.get_comparison_summary(db.CHAIN_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            
            error_str = os.path.basename(db.CHAIN_CONVEYOR_HORIZONTAL).split('.')[0].upper() + ' nor ' + os.path.basename(db.CHAIN_CONVEYOR_VERTICAL).split('.')[0].upper()
            self.hmi.add_comment('Error! Image not found: ' + error_str)
            raise ImageNotFoundError(error_str)
            

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor with 'C' conveyor ID prefix in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/5524dca3-cdaf-46c0-a5d9-3a90f2e0b049)
        '''

    def C3017939(self):
        '''HMI - ConveyorVisual - Belt'''
        self._navigate_via_scrollbox_to_conveyor('BT200070_01')
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        res = self.hmi.exists(db.BELT_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK) or self.hmi.exists(db.BELT_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
        
        if not res:
            self.hmi.get_comparison_summary(db.BELT_CONVEYOR_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            self.hmi.get_comparison_summary(db.BELT_CONVEYOR_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            
            error_str = os.path.basename(db.BELT_CONVEYOR_HORIZONTAL).split('.')[0].upper() + ' nor ' + os.path.basename(db.BELT_CONVEYOR_VERTICAL).split('.')[0].upper()
            self.hmi.add_comment('Error! Image not found: ' + error_str)
            raise ImageNotFoundError(error_str)
  
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor with 'B' conveyor ID prefix in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/193a690b-bcfb-4e8a-9921-ac2aa24c34a3)
        '''

    def C3017940(self):
        '''HMI - ConveyorVisual - LiftTable'''
        self._navigate_via_scrollbox_to_conveyor('RX100510')
        self.hmi.verify_on_screen(db.LIFT_TABLE_DEFAULT, mask=db.LIFT_TABLE_DEFAULT_MASK)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        res = self.hmi.exists(db.LIFT_TABLE_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK) or self.hmi.exists(db.LIFT_TABLE_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
        
        if not res:
            self.hmi.get_comparison_summary(db.LIFT_TABLE_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            self.hmi.get_comparison_summary(db.LIFT_TABLE_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            
            error_str = os.path.basename(db.LIFT_TABLE_HORIZONTAL).split('.')[0].upper() + ' nor ' + os.path.basename(db.LIFT_TABLE_VERTICAL).split('.')[0].upper()
            self.hmi.add_comment('Error! Image not found: ' + error_str)
            raise ImageNotFoundError(error_str)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any lift conveyor in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/4fe4c8fe-f5e7-41d9-8c19-ffcdef77f9d9)
        '''

    def C3017941(self):
        '''HMI - ConveyorVisual - TurnTable'''
        self._navigate_via_scrollbox_to_conveyor('RX100200')
        self.hmi.verify_on_screen(db.TURNTABLE_DEFAULT, mask=db.TURNTABLE_DEFAULT_MASK)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        res = self.hmi.exists(db.TURNTABLE_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK) or self.hmi.exists(db.TURNTABLE_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
        
        if not res:
            self.hmi.get_comparison_summary(db.TURNTABLE_VERTICAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            self.hmi.get_comparison_summary(db.TURNTABLE_HORIZONTAL, mask=db.GENERIC_CONVEYOR_PORT_MASK)
            
            error_str = os.path.basename(db.TURNTABLE_HORIZONTAL).split('.')[0].upper() + ' nor ' + os.path.basename(db.TURNTABLE_VERTICAL).split('.')[0].upper()
            self.hmi.add_comment('Error! Image not found: ' + error_str)
            raise ImageNotFoundError(error_str)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any turn conveyor in selection field.
         4. Select checkmark button.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. ![](index.php?/attachments/get/ad2417bb-f49b-4371-9b1c-267f3d6bc6b7)
        '''
    
class DynamicDataSequences(CommonPathwaysAndConfigurations):
    def __init__(self, hmi, plc):
        super().__init__(hmi, plc)
        
    def C3016638(self):
        '''HMI - ConveyorScreen - ConveyorColour - Auto mode'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.VIEW_SWITCH_OFF)
        time.sleep(3)
        self.hmi.verify_on_screen(db.CONVEYOR_AUTO, mask=db.GENERIC_CONVEYOR_PORT_MASK, critical=True)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Set conveyor into automatic mode.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is white.
        '''

    def C3016639(self):
        '''HMI - ConveyorScreen -ConveyorColour - Off/Inactive/Loading'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.verify_on_screen(db.CONVEYOR_INACTIVE, mask=db.GENERIC_CONVEYOR_PORT_MASK, critical=True)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Set conveyor into inactive mode.     Alternatively toggle on then off manual mode to trigger this mode.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is gray.
        '''

    def C3016640(self):
        '''HMI - ConveyorScreen - ConveyorColour - Manual mode'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.verify_on_screen(db.CONVEYOR_MANUAL, mask=db.GENERIC_CONVEYOR_PORT_MASK, critical=True)
        self.hmi.select(db.MANUAL_ON)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Set conveyor into manual mode.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is yellow.
        '''

    def C3016641(self):
        '''HMI - ConveyorScreen - ConveyorColour - Fault'''
        self._navigate_via_scrollbox_to_conveyor('RT100007')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU_DATA, wait_time=1)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.select(db.VIEW_SWITCH_OFF)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.verify_on_screen(db.CONVEYOR_FAULTED, mask=db.GENERIC_CONVEYOR_PORT_MASK, critical=True)
        self.hmi.select(db.DELETE_TU_DATA)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.select(db.FAULT_RESET)

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Trigger a fault in the conveyor.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is red.
        '''

    def C3016642(self):
        '''HMI - ConveyorScreen - IndicatorBox - Port logic'''
        self.hmi.blocked = True
        self.hmi.add_comment('Requires TU placement capabilities')
        return
        
        self.hmi.verify_on_screen(db.PORT_1_OCCUPIED_WHITE, critical=True)
        port_in_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port1Occupied.sensorActive')
       
        self.hmi.verify_on_screen(db.PORT_2_OCCUPIED_WHITE, critical=True)
        port_out_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port2Occupied.sensorActive')
        
        # Note: NOT active means blocked PE
        if (not port_in_active) or (not port_out_active):
            self._report_exception('PPE blocked but HMI shows unblocked status')

        #Place TU on previous conveyor, set into auto mode
        
        self.hmi.verify_on_screen(db.PORT_1_OCCUPIED_GREY, critical=True)
        port_in_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port1Occupied.sensorActive')
        
        self.hmi.verify_on_screen(db.PORT_2_OCCUPIED_GREY, critical=True)
        port_out_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port2Occupied.sensorActive')
        
        # Note: NOT active means blocked PE
        if port_in_active or port_out_active:
            self._report_exception('PE not blocked but HMI shows blocked status')
            
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Place TU onto adjacent conveyor feeding into selected conveyor.
         6. Wait for current conveyor screen to change as TU transfer completes.
         7. Wait for current conveyor screen to change as TU transfer from conveyor currently in HMI to next conveyor completes.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Adjacent conveyor begins TU transfer to the conveyor currently loaded in HMI.
         6. Port sensor indicator turns gray (low) indicating prescence of TU.
         7. Port sensor indicator turns back to white (high) indicating absence of TU.
        '''

    def C3016643(self):
        '''HMI - ConveyorScreen - Auto mode display sequence'''
        self.hmi.blocked = True
        self.hmi.add_comment('Requires TU placement capabilities')
        return

        self.hmi.verify_on_screen(db.PORT_1_OCCUPIED_WHITE, critical=True)
        port_in_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port1Occupied.sensorActive')
       
        self.hmi.verify_on_screen(db.PORT_2_OCCUPIED_WHITE, critical=True)
        port_out_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port2Occupied.sensorActive')
        
        # Note: NOT active means blocked PE
        if (not port_in_active) or (not port_out_active):
            self._report_exception('PE blocked but HMI shows unblocked status')
        
        occupied_visual_exists = self.hmi.exists(db.TU_OCCUPANCY, max_search_time=1)
        if occupied_visual_exists:
            self._report_exception('Conveyor occupied prior to transfer')
        
        #Place TU on previous conveyor, set into auto mode
        
        self.hmi.verify_on_screen(db.TU_OCCUPANCY, critical=True, max_search_time=10)
        conveyor_occupied = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.logicOccupied')
            
        # Note: NOT active means blocked PE
        if not conveyor_occupied:
            self._report_exception('Conveyor occupied visual present but PLC occupied signal is low')
            
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Place scanned TU onto adjacent conveyor feeding into selected conveyor.
         6. Wait for current conveyor screen to be populated with TU information as the TU transfer completes.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Adjacent conveyor begins TU transfer to the conveyor currently loaded in HMI.
         6. TU visual appears over the conveyor visual.     TU data fields populated.
        '''

    def C3016644(self):
        '''HMI - ConveyorScreen - Device data population'''
        self.hmi.blocked = True
        self.hmi.add_comment('Requires TU placement capabilities')
        return

        self.hmi.verify_on_screen(db.PORT_1_OCCUPIED_WHITE, critical=True)
        port_in_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port1Occupied.sensorActive')
       
        self.hmi.verify_on_screen(db.PORT_2_OCCUPIED_WHITE, critical=True)
        port_out_active = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.sensors.port2Occupied.sensorActive')
        
        # Note: NOT active means blocked PE
        if (not port_in_active) or (not port_out_active):
            self._report_exception('PE blocked but HMI shows unblocked status')
        
        data_occupied_visual = self.hmi.verify_on_screen(db.EMPTY_TU_DATA)
        
        #Place TU on previous conveyor, set into auto mode
        
        start_time = time.time()
        curr_time = start_time
        timeout = 10
        while curr_time - start_time < timeout:
            data_occupied = self.plc.get_plc_signal('Hmi.interface[1].status.selectedConv.dataOccupied')
            if data_occupied:
                break
            curr_time = time.time()
            
        if not data_occupied:
            self._report_exception('Conveyor never occupied with TU Data')
            
        if self.hmi.exists(db.EMPTY_TU_DATA, max_search_time=1):
            self._report_exception('TU Data fields not populated')
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor with an attached scanner device in selection field.
         4. Select checkmark button.
         5. Place unscanned TU onto adjacent conveyor feeding into selected conveyor.
         6. Wait for current conveyor screen to be populated with TU information as the TU transfer and scan completes.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Adjacent conveyor begins TU transfer to the conveyor currently loaded in HMI.
         6. TU visual appears over the conveyor visual.     TU data fields populated.     Scanner data fields populated.
        '''

    def C3016646(self):
        '''HMI - Banner - Time'''
        
        #Test case assumes the proper function of the system clock
        initial_time_hmi = self.hmi.read_region(self.banner_time_region)
        now = datetime.now()
        initial_time_system = now.strftime("%H:%M:%S")
        
        system_split = initial_time_system.split(':') 
        hmi_split = initial_time_hmi.split(':') 
        
        #Convert out of 24hr time
        if int(system_split[0]) > 12:
            curr_num = int(system_split[0])
            system_split[0] = str(curr_num-12)
        
        hmi_total_time_seconds = 60*60*int(hmi_split[0]) + 60*int(hmi_split[1]) + int(hmi_split[2])
        system_total_time_seconds = 60*60*int(system_split[0]) + 60*int(system_split[1]) + int(system_split[2])

        if (abs(hmi_total_time_seconds-system_total_time_seconds) > 1):
            print(system_split, hmi_split, flush=True)
            self._report_exception('HMI time not equal to system time')
        
        time.sleep(3)
        
        final_time_hmi = self.hmi.read_region(self.banner_time_region)
        now = datetime.now()
        final_time_system = now.strftime("%H:%M:%S")
        
        system_split = final_time_system.split(':') 
        hmi_split = final_time_hmi.split(':') 
        
        if int(system_split[0]) > 12:
            curr_num = int(system_split[0])
            system_split[0] = str(curr_num-12)
        
        hmi_total_time_seconds = 60*60*int(hmi_split[0]) + 60*int(hmi_split[1]) + int(hmi_split[2])
        system_total_time_seconds = 60*60*int(system_split[0]) + 60*int(system_split[1]) + int(system_split[2])

        if (abs(hmi_total_time_seconds-system_total_time_seconds) > 1):
            print(system_split, hmi_split, flush=True)
            self._report_exception('HMI time not equal to system time')
            
        '''
        Steps:
         1. Record time as displayed in the HMI banner.
         2. Wait a set time period.

        Results:
         1. Start time is recorded for later comparison.
         2. Time change is reflected in the time displayed in the HMI banner including whether the time is AM or PM.
        '''

    def C3016647(self):
        '''HMI - Banner - Date'''
        date_hmi = self.hmi.read_region(self.banner_date_region, psm_mode=7) #**self.read_numbers_config)
        hmi_split = date_hmi.split('/') 
        
        now = datetime.now()
        date_system = now.strftime("%m/%d/%Y")
        
        system_split = date_system.split('/') 
        print(date_hmi, date_system, flush=True)
        
        for i in range(3):
            if int(hmi_split[i]) != int(system_split[i]):
                self._report_exception('HMI date not equal to system date')
        
        '''
        Steps:
         1. Record date as displayed in the HMI banner.
         2. Wait a set time period in the span of days.

        Results:
         1. Start date is recorded for later comparison.
         2. Date change is reflected in the date displayed in the HMI banner.
        '''

    def C3016648(self):
        '''HMI - ConveyorOverviews - Occupancy indication'''
        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU)
        self.hmi.select(db.DEMATIC)
        self._navigate_to_zone_overview()
        self.hmi.verify_on_screen(db.ZONE_OVERVIEW_OCCUPIED, search_region=self.zone_overview_inspection_region, critical=True)
        self.hmi.select(db.ELEVATOR_LOOP)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_OCCUPIED, mask=db.CONVEYOR_OVERVIEW_MASK, search_region=self.conveyor_overview_inspection_region, critical=True)
        self.hmi.select(db.DEMATIC)
        self._navigate_via_scrollbox_to_conveyor('RT100025', clean=False)
        self.hmi.select(db.REMOVE_TU)
        self.hmi.select(db.MANUAL_ON)
        
        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select any conveyor in zone.
         5. Select manual mode.
         6. Select add TU button.
         7. Press return button to navigate back to one of the overview screens.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. Detailed conveyor screen loads.
         5. Conveyor screen switches to manual view.
         6. Conveyor screen displays TU on conveyor.
         7. TU is represented by a black box on top of the conveyor.
        '''

    def C3016649(self):
        '''HMI - ConveyorOverviews - ConveyorColour - Auto mode'''
        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.DEMATIC)
        self._navigate_to_zone_overview()
        self.hmi.verify_on_screen(db.ZONE_OVERVIEW_AUTO, search_region=self.zone_overview_inspection_region, critical=True)
        self.hmi.select(db.ELEVATOR_LOOP)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_AUTO, mask=db.CONVEYOR_OVERVIEW_MASK, search_region=self.conveyor_overview_inspection_region, critical=True)
            
        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select any conveyor in zone.
         5. Set conveyor into automatic mode.
         6. Press return button to navigate back to one of the overview screens.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is white.
         6. Conveyor visual on overview screen is white.
        '''

    def C3016650(self):
        '''HMI - ConveyorOverviews - ConveyorColour - Off/Inactive/Loading'''
        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.select(db.DEMATIC)
        self._navigate_to_zone_overview()
        self.hmi.verify_on_screen(db.ZONE_OVERVIEW_INACTIVE, search_region=self.zone_overview_inspection_region, critical=True)
        self.hmi.select(db.ELEVATOR_LOOP)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_INACTIVE, mask=db.CONVEYOR_OVERVIEW_MASK, search_region=self.conveyor_overview_inspection_region, critical=True)
            
        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select any conveyor in zone.
         5. Set conveyor into inactive mode.     Alternatively toggle on then off manual mode to trigger this mode.
         6. Press return button to navigate back to one of the overview screens.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is gray.
         6. Conveyor visual on overview screen is gray.
        '''

    def C3016651(self):
        '''HMI - ConveyorOverviews - ConveyorColour - Manual mode'''
        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.DEMATIC)
        self._navigate_to_zone_overview()
        self.hmi.verify_on_screen(db.ZONE_OVERVIEW_MANUAL, search_region=self.zone_overview_inspection_region, critical=True)
        self.hmi.select(db.ELEVATOR_LOOP)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_MANUAL, mask=db.CONVEYOR_OVERVIEW_MASK, search_region=self.conveyor_overview_inspection_region, critical=True)
        self.hmi.select(db.DEMATIC)
        self._navigate_via_scrollbox_to_conveyor('RT100025', clean=False)
        self.hmi.select(db.MANUAL_ON)

        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select any conveyor in zone.
         5. Set conveyor into manual mode.
         6. Press return button to navigate back to one of the overview screens.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is yellow.
         6. Conveyor visual on overview screen is yellow.
        '''

    def C3016652(self):
        '''HMI - ConveyorOverviews - ConveyorColour - Fault'''
        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU_DATA, wait_time=1)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.select(db.DEMATIC)
        self._navigate_to_zone_overview()
        self.hmi.verify_on_screen(db.ZONE_OVERVIEW_FAULTED, search_region=self.zone_overview_inspection_region, critical=True)
        self.hmi.select(db.ELEVATOR_LOOP)
        self.hmi.verify_on_screen(db.CONVEYOR_OVERVIEW_FAULTED, mask=db.CONVEYOR_OVERVIEW_MASK, search_region=self.conveyor_overview_inspection_region, critical=True)
        self.hmi.select(db.DEMATIC)
        self._navigate_via_scrollbox_to_conveyor('RT100025', clean=False)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.DELETE_TU_DATA)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.select(db.FAULT_RESET)
        
        '''
        Steps:
         1. Select 'Layout Overview' from overview selection dropdown.
         2. Press to continue.
         3. Select any conveyor zone.
         4. Select any conveyor in zone.
         5. Trigger a fault in the conveyor.
         6. Press return button to navigate back to one of the overview screens.

        Results:
         1. Keyphrase 'Layout Overview' appears in overview selection box.
         2. Conveyor zone selection screen loads.
         3. Conveyor selection screen loads.
         4. Detailed conveyor screen loads.
         5. Conveyor visual is red.
         6. Conveyor visual on overview screen is red.
        '''

    def C3016653(self):
        '''HMI - AlarmList - New warning'''
        self.hmi.blocked = True
        self.hmi.add_comment('Requires ability to force warning')

        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Select warning symbol button.
         6. Trigger a warning for the current conveyor.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Alarm list filtered to only  display the current conveyor alarms appears. 
         6. Yellow warning message is added to the alarm list display.
        '''

    def C3016654(self):
        '''HMI - AlarmList - New fault'''
        self.hmi.blocked = True
        self.hmi.add_comment('Requires ability to force fault')

        self._navigate_via_scrollbox_to_conveyor('RT100025')
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.ADD_TU_DATA, wait_time=1)
        self.hmi.select(db.MANUAL_ON)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.verify_on_screen(db.ALARM_FAULT_MESSAGE)
        self.hmi.select(db.RETURN)
        self.hmi.select(db.MANUAL_OFF)
        self.hmi.select(db.DELETE_TU_DATA)
        self.hmi.select(db.SWITCH_TO_ALARM_SCREEN)
        self.hmi.select(db.FAULT_RESET)
        
        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Select warning symbol button.
         6. Trigger a fault for the current conveyor.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Alarm list filtered to only  display the current conveyor alarms appears. 
         6. Red fault message is added to the alarm list display.
        '''

    def C3016655(self):
        '''HMI - AlarmList - New exception'''
        
        self.hmi.blocked = True
        self.hmi.add_comment('Requires ability to force exception')

        '''
        Steps:
         1. Select 'Scrollbox Overview' from overview selection dropdown.
         2. Press to continue.
         3. Enter any conveyor in selection field.
         4. Select checkmark button.
         5. Select warning symbol button.
         6. Trigger an exception for the current conveyor.

        Results:
         1. Keyphrase 'Scrollbox Overview' appears in overview selection box.
         2. Conveyor selection screen loads.
         3. Conveyor name appears in conveyor selection box.
         4. Detailed conveyor screen loads.
         5. Alarm list filtered to only  display the current conveyor alarms appears. 
         6. Blue exception message is added to the alarm list display.
        '''