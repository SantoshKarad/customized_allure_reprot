# import required module
import os
 
# assign directory
DIR = os.path.dirname(__file__)
PARENT_DIR = os.path.dirname(DIR)
IMAGE_DB_PATH = os.path.join(PARENT_DIR, r'image_database')
IMAGE_DB_PYTHON_PATH = os.path.join(PARENT_DIR, r'case_definitions\image_db.py')

# iterate over files in
# that directory
files = []
for root, dirs, _ in os.walk(IMAGE_DB_PATH):
    
    for filename in os.scandir(root):
        relative_path = os.path.relpath(filename, IMAGE_DB_PATH)
        path, f_ext = os.path.splitext(filename)
        f_name = os.path.basename(os.path.normpath(path))
        if f_ext == '.png':
            files.append((f_name, relative_path))
                
with open(IMAGE_DB_PYTHON_PATH, 'a') as f:
    f.truncate(0)
    f.write('import os \n\nDIR = os.path.dirname(__file__)\nPARENT_DIR = os.path.dirname(DIR)\nIMAGE_FOLDER_PATH = os.path.join(PARENT_DIR, r\'image_database\')\n\nclass ImageDatabase():\n')
    
    for f_name, dir in files:
        f.write('\t' + f_name.upper() + ' = os.path.join(IMAGE_FOLDER_PATH, ' + 'r\''+ dir + '\')\n')
            