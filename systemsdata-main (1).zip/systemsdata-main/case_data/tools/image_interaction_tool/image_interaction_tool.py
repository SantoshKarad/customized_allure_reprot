# Adapted from: https://stackoverflow.com/questions/6916054/how-to-crop-a-region-selected-with-mouse-click-using-python
#licence: https://creativecommons.org/licenses/by-sa/4.0/

# requirements: matplotlib, tkinter, PIL, numpy

import numpy as np
from PIL import ImageGrab, Image
from tkinter import simpledialog
import tkinter
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('tkAgg') # Set packge to use tkinter GUI backend

from matplotlib import backend_bases
backend_bases.NavigationToolbar2.toolitems = (
        ('Home', 'Reset original view', 'home', 'home'),
        ('Back', 'Back to  previous view', 'back', 'back'),
        ('Forward', 'Forward to next view', 'forward', 'forward'),
        (None, None, None, None),
        ('Pan', 'Pan axes with left mouse, zoom with right', 'move', 'pan'),
        ('Zoom', 'Zoom to rectangle', 'zoom_to_rect', 'zoom'),
        (None, None, None, None),
      )

     
import matplotlib.widgets as widgets
import matplotlib.pyplot as plt
from dematic.hmi.gui_automation import *
from matplotlib.widgets import Button, TextBox, CheckButtons
from matplotlib.backends.backend_tkagg import FigureCanvasTk, NavigationToolbar2Tk
import time

DIR = os.path.dirname(__file__)

def save_selection(val):
    try:
        rgbArray = sub_im
        newimage = Image.new('RGB', (len(rgbArray[0]), len(rgbArray)))  # type, size
        newimage.putdata([tuple(p) for row in rgbArray for p in row])
        filename = simpledialog.askstring("Input","Enter the name of the file (including file extension)",parent=root)
        newimage.save(filename) # takes type from filename extension
        print('Save successful')
    except:
        print('Save failed')

def plot_hmi(val):
    global sub_im
    global arr
    global hmi_region_no_banner
    sub_im = arr[hmi_region_no_banner.origin.y:hmi_region_no_banner.origin.y+hmi_region_no_banner.height, hmi_region_no_banner.origin.x:hmi_region_no_banner.origin.x+hmi_region_no_banner.width]
    ax2.clear()
    ax2.imshow(sub_im)
     
def refresh_screen(val):
    global arr
    global rs
    global hmi_region_banner
    global hmi_region_no_banner
    del rs
    
    hmi.focus()
    hmi_region_banner = hmi._get_window_region()
    hmi_region_no_banner = hmi._get_window_region(banner=False)
    ax.clear()
    manager.window.attributes("-alpha", 0)
    time.sleep(0.5)
    im = ImageGrab.grab()
    arr = np.asarray(im)
    ax.imshow(arr)

    rs=widgets.RectangleSelector(
        ax, on_select,
        props = dict(facecolor='blue', edgecolor = 'red', alpha=1, fill=False))
    
    time.sleep(0.5)    
    manager.window.attributes("-alpha", 1)
    
def update_width(expr):
    global selection_width
    selection_width = int(expr)
    
def update_height(expr):
    global selection_height
    selection_height = int(expr)
 
def update_strict(expr):
    global strict
    strict = fnext.get_status()[0]
    
def on_select(eclick, erelease):
    global sub_im, strict, selection_width, selection_height
    if eclick.ydata>erelease.ydata:
        eclick.ydata,erelease.ydata=erelease.ydata,eclick.ydata
    if eclick.xdata>erelease.xdata:
        eclick.xdata,erelease.xdata=erelease.xdata,eclick.xdata
        
    if strict is False:
        str = '\nRelative to Screen - Origin: (%d,%d), Width: %d, Height: %d\nRelative to HMI - Origin: (%d,%d), Width: %d, Height: %d' % (round(eclick.xdata), round(eclick.ydata), round(erelease.xdata) - round(eclick.xdata), round(erelease.ydata) - round(eclick.ydata), 
            round(eclick.xdata)-hmi_region_banner.origin.x, round(eclick.ydata)-hmi_region_banner.origin.y, round(erelease.xdata) - round(eclick.xdata), round(erelease.ydata) - round(eclick.ydata))
    else:
        pass
        str = '\nRelative to Screen - Origin: (%d,%d), Width: %d, Height: %d\nRelative to HMI - Origin: (%d,%d), Width: %d, Height: %d' % (round(eclick.xdata), round(eclick.ydata), selection_height, selection_height, 
            round(eclick.xdata)-hmi_region_banner.origin.x, round(eclick.ydata)-hmi_region_banner.origin.y, selection_width, selection_height)
        
    ax2.clear()
    if strict is False:
        sub_im = arr[round(eclick.ydata):round(erelease.ydata), round(eclick.xdata):round(erelease.xdata)]
    else:
        pass
        sub_im = arr[round(eclick.ydata):round(eclick.ydata)+selection_height, round(eclick.xdata):round(eclick.xdata)+selection_width]
    
    ax2.imshow(sub_im)
    plt.xticks([])
    plt.yticks([])
    plt.xlabel(str, fontsize=10)
    fig.canvas.draw()

def on_click(event):
    global sub_im, strict, selection_width, selection_height
    if strict and event.inaxes==ax:
        x = round(event.xdata)
        y = round(event.ydata)
        str = '\nRelative to Screen - Origin: (%d,%d), Width: %d, Height: %d\nRelative to HMI - Origin: (%d,%d), Width: %d, Height: %d' % (x, y, selection_height, selection_height, 
            x-hmi_region_banner.origin.x, y-hmi_region_banner.origin.y, selection_width, selection_height)
        
        ax2.clear()
        sub_im = arr[y:y+selection_height, x:x+selection_width]
        ax2.imshow(sub_im)
        plt.xticks([])
        plt.yticks([])
        plt.xlabel(str, fontsize=10)
        fig.canvas.draw()

if __name__ == '__main__':
    
    # Core HMI paths   
    config_tree = ET.parse('config.xml')
    config_root = config_tree.getroot()
    WINCC_EXE_PATH = r'%s' % config_root.find('wincc_exe_path').text
    HMI_PATH = r'%s' % config_root.find('hmi_path').text
    
    hmi = HMI(WINCC_EXE_PATH, HMI_PATH, 'SIMATIC WinCC Runtime Advanced')
    hmi.focus()
    hmi_region_banner = hmi._get_window_region()
    hmi_region_no_banner = hmi._get_window_region(banner=False)
    
    # For save file GUI
    root = tkinter.Tk()
    root.withdraw()
    
    # Global plot settings and initialisation
    fig = plt.figure()
    manager = plt.get_current_fig_manager()
    manager.window.state('zoomed')
    
    # Screen explorer plot (left-side)
    ax = fig.add_subplot(121)
    plt.xticks([])
    plt.yticks([])
    
    # Get screen and plot
    im = ImageGrab.grab()
    arr = np.asarray(im)
    plt.imshow(arr)
    
    selection_width=0
    selection_height=0
    strict = False
    
    # Region selection widget
    rs=widgets.RectangleSelector(
        ax, on_select, minspanx=0, minspany=-0,
        props = dict(facecolor='blue', edgecolor = 'red', alpha=1, fill=False))
    
    # Save button
    axes = plt.axes([0, 0.15, 0.075, 0.03])
    bnext = Button(axes, 'Save Selection',color="white")
    bnext.on_clicked(save_selection)
    
    # Save button
    axes_ref_1 = plt.axes([0, 0.10, 0.075, 0.03])
    cnext = Button(axes_ref_1, 'Refresh screen',color="white")
    cnext.on_clicked(refresh_screen)
    
    # Width button
    axes_ref_2 = plt.axes([0.09, 0.025, 0.02, 0.03])
    dnext = TextBox(axes_ref_2, 'Width ', initial = '0', color="white")
    dnext.on_submit(update_width)
    
    # Height button
    axes_ref_3 = plt.axes([0.14, 0.025, 0.02, 0.03])
    enext = TextBox(axes_ref_3, 'Height ', initial = '0', color="white")
    enext.on_submit(update_height)
    
    # Toggle button
    axes_ref_4 = plt.axes([0.0, 0.01, 0.05, 0.075])
    fnext = CheckButtons(axes_ref_4, ['Strict\nselection'])
    fnext.on_clicked(update_strict)
    
     # Save button
    axes_ref_5 = plt.axes([0, 0.2, 0.075, 0.03])
    gnext = Button(axes_ref_5, 'Capture HMI Screen',color="white")
    gnext.on_clicked(plot_hmi)

    cid = fig.canvas.mpl_connect('button_press_event', on_click)

    # Screen region plot
    ax2 = fig.add_subplot(122)
    plt.xticks([])
    plt.yticks([])

    plt.show()