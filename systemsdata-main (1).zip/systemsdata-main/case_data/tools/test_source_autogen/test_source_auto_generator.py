import pandas as pd 
import os
import test_source as tests
from dematic.hmi.gui_automation import *
from image_db import * 
DIR = os.path.dirname(__file__)
FILE_PATH = os.path.join(DIR, 'cases.csv')

# Retrieve excel spreadsheet
def getExcel():
    df = pd.read_csv(FILE_PATH)
    return df

# Read excel fields into appropriate parameter fields
def extractExcelInfo(df, tests_instance):

    method_list = [method for method in dir(tests_instance) if method.startswith('__') is False]
    with open('test_source.txt', 'a') as f:
        f.truncate(0)
        
    for _ , row in df.iterrows():
        if(row['ID'] not in method_list):
            str = row['Steps (Step)'].split('\n')
            expected = row['Steps (Expected Result)'].split('\n')
            with open('test_source.txt', 'a') as f:
                f.write('def %s(self):\n' % row['ID'])
                f.write('\t\'\'\'%s\'\'\'\n' % row['Title'])
                f.write('\tpass\n')
                f.write('\n\t\'\'\'\n')
                f.write('\tSteps:\n')
                for i in str:
                    f.write('\t %s' % i)
                
                f.write('\n\n')
                
                f.write('\tResults:\n')
                for i in expected:
                    f.write('\t %s' % i)
               
                f.write('\n\t\'\'\'')
                f.write('\n\n')
                
if __name__ == '__main__':

    hmi = HMI(WINCC_EXE_PATH, HMI_PATH, 'SIMATIC WinCC Runtime Advanced')
    ti = tests.Sequences(hmi)
    df = getExcel()
    extractExcelInfo(df, ti)