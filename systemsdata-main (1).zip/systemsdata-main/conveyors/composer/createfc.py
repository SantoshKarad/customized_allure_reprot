
import sys
import os
import xml.etree.ElementTree as ET


def main(args):
    if len(args) != 4:
        print("Incorrect arguments")
        sys.exit(1)
    composition_file = args[1]
    template_file = args[2]
    output_file = args[3]

    if not os.path.exists(composition_file):
        print("Composition file not found")
        sys.exit(1)
    elif not os.path.exists(template_file):
        print("Template file not found")
        sys.exit(1)

    composition_tree = ET.parse(composition_file)
    composition_root = composition_tree.getroot()
    calls = []
    for lib in composition_root.findall('Library'):
        # Escape chars in fn name e.g. &amp;
        calls.append(lib.get('Fn').replace('&', "&amp;"))
    if calls:
        offset = 24
        structured_content = ""
        for i in range(len(calls)):
            structured_content += """  <Access Scope="Call" UId="%i">
                <CallInfo UId="%i" BlockType="FC">
                  <Instance Scope="GlobalVariable" UId="%i">
                    <Component Name="%s" UId="%i" />
                  </Instance>
                  <Token Text="(" UId="%i" />
                  <Token Text=")" UId="%i" />
                </CallInfo>
              </Access>
              <Token Text=";" UId="%i" />
              <NewLine Num="1" UId="%i" />
            """ % (
                    offset + (i * 8) + 1,
                    offset + (i * 8) + 2,
                    offset + (i * 8) + 3,
                    calls[i],
                    offset + (i * 8) + 4,
                    offset + (i * 8) + 5,
                    offset + (i * 8) + 6,
                    offset + (i * 8) + 7,
                    offset + (i * 8) + 8
                )
        # The content is small, so take it all in
        # ET parsing will reformat the namespacing
        # so using original text template
        template_content = None
        with open(template_file) as fh:
            template_content = fh.read()
        if template_content:
            try:
                with open(output_file, 'w') as fh:
                    fh.write(template_content % structured_content)
            except Exception as e:
                print("Exception writing output")
                print(e)
                sys.exit(1)

if __name__ == "__main__":
    sys.exit(main(sys.argv))
