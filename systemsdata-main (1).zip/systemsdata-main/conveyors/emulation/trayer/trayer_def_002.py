
from dematic.emulation.command import Commander

from setup_commands import setup_hold_by_time
from exe_commands import exe_pick_immediate, exe_end_when_vacated, exe_drop_immediate
from teardown_commands import teardown_end_by_time


description     = "DMCP trayer 1 small case"
model_file_name = "loops/case_trayer.json"
msg_server_tsap = "PLCWCS2"
msg_local_tsap  = "WCSPLC2"
config = []
commander = Commander()
#
# Wait in setup for a fixed 5 secs before proceeding
#
setup_hold_by_time(commander, 5)
#
# Set conveyor to pick immediately once occupied
#
exe_pick_immediate(commander, "410315_01")
#
# End the run once all cases have been evacuated
#
exe_end_when_vacated(
    commander,
    (
        "410105_01",
        "410105_02",
        "410105_03",
        "TRAYER_1_ULZ1",
        "TRAYER_1_ULZ2",
        "TRAYER_1_ULZ3",
        "TRAYER_1_ULZ4",
        "TRAYER_1_LLZ5",
        "TRAYER_1_LLZ6",
        "410315_01"
    )
)
#
# Immediately drop cases from the list onto the trayer in sequence
#
exe_drop_immediate(
    commander,
    "410105_01",
    ((405, 290, 240), )
)
#
# Drop trays onto the conveyors as soon as the tray conveyors are vacant
#
exe_drop_immediate(commander, "410305_01", ((525, 375, 55, "tray"),), True)
exe_drop_immediate(commander, "410205_01", ((725, 525, 55, "tray"),), True)
#
# Allow 1 second for the PLC to acknowledge the end state before ending
#
teardown_end_by_time(commander, 1)
