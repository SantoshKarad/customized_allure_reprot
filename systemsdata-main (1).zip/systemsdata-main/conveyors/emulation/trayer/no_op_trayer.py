
from dematic.emulation.execution.command import Commander


description     = "No operation - trayer loop"
model_file_name = "loops/case_trayer.json"
msg_server_tsap = "PLCWCS2"
msg_local_tsap  = "WCSPLC2"
config          = []
commander       = Commander()
