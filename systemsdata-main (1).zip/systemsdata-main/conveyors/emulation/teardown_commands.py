
import datetime as DT


def teardown_hold_by_time(commander, t_s):
    """Hold this setup action incomplete for t_s seconds"""
    description = "Hold for %ss at end" % t_s
    def condition(self):
        # Create new instance var to hold state
        if not hasattr(self, "teardown_hold_by_time_start_t"):
            self.teardown_hold_by_time_start_t = DT.datetime.now()
        elapsed_time = DT.datetime.now() - self.teardown_hold_by_time_start_t
        if elapsed_time.seconds < t_s:
            return False
        return True
        
    def action(self):
        self.active = False
    return commander.register_teardown(description, condition, action)

def teardown_end_by_time(commander, t_s):
    """Hold this setup action incomplete for t_s seconds"""
    description = "Hold for %ss at end" % t_s
    def condition(self):
        # Create new instance var to hold state
        if not hasattr(self, "teardown_hold_by_time_start_t"):
            self.teardown_hold_by_time_start_t = DT.datetime.now()
        elapsed_time = DT.datetime.now() - self.teardown_hold_by_time_start_t
        if elapsed_time.seconds < t_s:
            return False
        return True
        
    def action(self):
        self.commander.end()
        self.active = False
    return commander.register_teardown(description, condition, action)