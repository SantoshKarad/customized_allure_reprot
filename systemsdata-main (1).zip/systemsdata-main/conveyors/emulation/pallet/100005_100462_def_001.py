
import dematic.dci.dci as dci_conveyor
from dematic.dci.messenger import Messenger
from dematic.emulation.execution.command import Commander

from setup_commands import setup_hold_by_time
from exe_commands import exe_pick_lhd, exe_end_when_vacated, exe_drop_lhd, exe_drop_immediate
from teardown_commands import teardown_end_by_time

description     = "Pallet mission 100005 - 100462 default"
model_file_name = ("loops/pallet.json", "loops/elevator_132.json", "loops/pdc01.json")
msg_server_tsap = "PLCWCS1"
msg_local_tsap  = "WCSPLC1"
config          = []
commander = Commander()

#
# Wait in setup for a fixed 5 secs before proceeding
#
setup_hold_by_time(commander, 5)
#
# Set conveyor to pick once occupied
#
exe_pick_lhd(commander, "100462")
#
# End the run once all TUs have been evacuated
#
exe_end_when_vacated(
    commander,
    (
        "100005",
        "100007",
        "100010",
        "100012",
        "100015",
        "100020",
        "100025",
        "100030",
        "100035",
        "100040",
        "100045",
        "100080",
        "100200",
        "100300",
        "100310",
        "100325",
        "100330",
        "100340",
        "100345",
        "100350",
        "100395",
        "100405",
        "100410",
        "100420",
        "100445",
        "100455",
        "100456",
        "100457",
        "100460",
        "100461",
        "100462"
    )
)
#
# Drop TU from the list onto the conveyor
#
exe_drop_lhd(commander, "100005", [[]])
#
# Allow 3 seconds for the PLC to acknowledge the end state before ending
#
teardown_end_by_time(commander, 3)

def dci_message_handler(msg, dci_send_queue, status_queue):
    if msg.message_type == "TUDR":
        msg = dci_conveyor.Tudr(message_bytes=msg.message_bytes)
        resp = dci_conveyor.Tumi(complement=msg)
        resp.cycle_count += 1
        if msg.current =="PCTA01IS01":
            resp.destination = "PCTA01PL20"
        elif msg.current =="PCTA01IS05":
            resp.destination = "PCTA01PL20"
        resp.build()
        dci_send_queue.put((1, resp.message_bytes))
            