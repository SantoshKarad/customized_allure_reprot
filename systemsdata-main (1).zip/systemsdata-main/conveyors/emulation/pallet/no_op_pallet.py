
from dematic.emulation.execution.command import Commander


description     = "No operation - pallet loop"
model_file_name = (
    "loops/case.json",
    "loops/pallet.json",
    "loops/trayer.json",
    "loops/agv.json",
    "loops/gtp.json",
    "loops/monorail.json",
    "loops/elevator_132.json",
    "loops/pdc01.json",
    "loops/pdc02.json",
    "loops/plc01.json",
    "loops/plc02.json"
)
msg_server_tsap = "PLCWCS1"
msg_local_tsap  = "WCSPLC1"
config          = []
commander       = Commander()
