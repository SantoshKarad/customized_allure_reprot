
def exe_pick_immediate(commander, conveyor_id):
    """Immediately pick items from the conveyor. Repeated"""
    description = "Immediate pick on %s" % conveyor_id
    def condition(self):
        if (
            conveyor_id in self.model.children
            and self.model.children[conveyor_id].occupied
        ):
            self.model.children[conveyor_id].children["lhd"].remove_tu()
        return False
        
    def action(self):
        pass
        
    return commander.register(description, condition, action)
    
def exe_pick_lhd(commander, conveyor_id):
    """Pick items from the conveyor. Repeated"""
    description = "LHD pick on %s" % conveyor_id
    def condition(self):
        if (
            conveyor_id in self.model.children
            and self.model.children[conveyor_id].occupied
        ):
            self.model.children[conveyor_id].do_pick = True
        return False
        
    def action(self):
        pass
        
    return commander.register(description, condition, action)
    
def exe_end_when_vacated(commander, conveyor_id_list):
    """End the run when all the conveyors are vacant"""
    description = "End when all cases expelled"
    def condition(self):
        if not hasattr(self, "exe_end_when_vacated_occupied_init"):
            self.exe_end_when_vacated_occupied_init = False
            
        for conveyor_id in conveyor_id_list:
            if conveyor_id not in self.model.children:
                continue
            if not self.model.children[conveyor_id].vacant:
                self.exe_end_when_vacated_occupied_init = True
                return False
        if self.exe_end_when_vacated_occupied_init:
            return True
        return False
    
    def action(self):
        # Clean for possible re-run
        del self.__dict__["exe_end_when_vacated_occupied_init"]
        self.commander.end_run()
        
    return commander.register(description, condition, action)
    
def exe_drop_immediate(commander, conveyor_id, tus_args_list, repeat=False):
    description = "Drop TU on %s" % conveyor_id
    def condition(self):
        # Create new instance var to hold state
        if not hasattr(self, "exe_drop_immediate_tu_idx"):
            self.exe_drop_immediate_tu_idx = 0
        if (
            conveyor_id in self.model.children
            and self.model.children[conveyor_id].vacant
        ):
            if self.exe_drop_immediate_tu_idx < len(tus_args_list):
                tu=self.model.children["tracker"].create(*tus_args_list[self.exe_drop_immediate_tu_idx])
                self.model.children[conveyor_id].children["lhd"].place_tu(tu=tu)
                self.exe_drop_immediate_tu_idx += 1
            else:
                if not repeat:
                    return True
                elif len(tus_args_list) == self.exe_drop_immediate_tu_idx:
                    self.exe_drop_immediate_tu_idx = 0
        return False
        
    def action(self):
        del self.__dict__["exe_drop_immediate_tu_idx"]
        self.active = False
        
    return commander.register(description, condition, action)
    
def exe_drop_lhd(commander, conveyor_id, tus_args_list, repeat=False):
    description = "Drop TU on %s" % conveyor_id
    def condition(self):
        # Create new instance var to hold state
        if not hasattr(self, "exe_drop_lhd_tu_idx"):
            self.exe_drop_lhd_tu_idx = 0
        if (
            conveyor_id in self.model.children
            and self.model.children[conveyor_id].vacant
        ):
            if self.exe_drop_lhd_tu_idx < len(tus_args_list):
                tu=self.model.children["tracker"].create(*tus_args_list[self.exe_drop_lhd_tu_idx])
                self.model.children[conveyor_id].do_drop = True
                self.exe_drop_lhd_tu_idx += 1
            else:
                if not repeat:
                    return True
                elif len(tus_args_list) == self.exe_drop_lhd_tu_idx:
                    self.exe_drop_lhd_tu_idx = 0
        return False
        
    def action(self):
        del self.__dict__["exe_drop_lhd_tu_idx"]
        self.active = False
        
    return commander.register(description, condition, action)
    