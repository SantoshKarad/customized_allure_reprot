
import datetime as DT


def setup_hold_by_time(commander, t_s):
    """Hold this setup action incomplete for t_s seconds"""
    description = "Hold for %ss at start" % t_s
    def condition(self):
        # Create new instance var to hold state
        if not hasattr(self, "start_t"):
            self.start_t = DT.datetime.now()
        elapsed_time = DT.datetime.now() - self.start_t
        if elapsed_time.seconds < t_s:
            return False
        return True
        
    def action(self):
        self.active = False
    return commander.register_setup(description, condition, action)