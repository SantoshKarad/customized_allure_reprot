
from dematic.emulation.execution.command import Commander


description     = "No operation - case loop"
model_file_name = "loops/case.json"
msg_server_tsap = "PLCWCS2"
msg_local_tsap  = "WCSPLC2"
config          = []
commander       = Commander()
